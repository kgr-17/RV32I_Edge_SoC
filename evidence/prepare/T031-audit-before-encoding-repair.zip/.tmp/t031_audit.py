from pathlib import Path
import datetime as dt,hashlib,json,subprocess,sys,zipfile
sys.path.insert(0,str(Path('scripts').resolve()));sys.path.insert(0,str(Path('dv/integration').resolve()))
import harness
from closure_checks import metadata_objects
from firmware_image import parse_elf,words
from soc_model import check_trace
from board_checks import validate_xpr
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
_,state=harness.load();receipt=state['receipts']['T031'];journal=harness.read(harness.inside(receipt))
assert state['task_states']['T031']=='completed' and state['active'] is None
assert journal['stage']=='finished' and len(journal['commands'])==4 and all(r['status']=='PASS' and r['exit_code']==0 for r in journal['commands'])
tools={};artifacts={};sources={}
def artifact(name,digest):
    p=harness.inside(name);assert sha(p)==digest,name;artifacts[p.relative_to(harness.ROOT).as_posix()]=digest
def visit(obj):
    if isinstance(obj,list):
        for value in obj:visit(value)
    elif isinstance(obj,dict):
        name=obj.get('evidence')
        if isinstance(name,str):name=name.replace('\\','/')
        if isinstance(name,str) and name.startswith('evidence/toolchain_runs/') and name not in tools:
            r=harness.read(harness.inside(name));assert r['status']=='PASS' and r['checks'] and all(c['status']=='PASS' for c in r['checks'])
            assert dt.datetime.strptime(r['started_utc'],'%Y%m%dT%H%M%S%fZ').replace(tzinfo=dt.timezone.utc)>=dt.datetime.fromisoformat(journal['commands'][0]['started_utc'])
            tools[name]=r;visit(r)
        for name,digest in obj.get('source_sha256',{}).items():
            assert sha(harness.inside(name))==digest,name;sources[name]=digest
        if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):artifact(obj['path'],obj['sha256'])
        for name,digest in obj.get('artifacts',{}).items():artifact(name,digest)
        for key in ('vector','waveform'):
            if key+'_sha256' in obj:artifact(obj.get(key+'_path',obj.get(key)),obj[key+'_sha256'])
        if isinstance(obj.get('stdout'),str):
            for value in metadata_objects(obj['stdout']):visit(value)
        for key,value in obj.items():
            if key!='stdout' and isinstance(value,(dict,list)):visit(value)
visit(journal['commands'])
assert len(tools)==3 and {r['profile'] for r in tools.values()}=={'lint','top','soc'}
soc=next(r for r in tools.values() if r['profile']=='soc');lint=next(r for r in tools.values() if r['profile']=='lint')
manifest=harness.read(harness.inside('config/rtl_checks.json'))
expected={d['top'] for d in manifest['lint_designs']+manifest['designs']}
seen={c['name'].split('Synthesis lint ',1)[1] for c in lint['checks'] if c['name'].startswith('Synthesis lint ')}
assert expected==seen and sum(c['name']=='Inferred latch explicitly rejected' for c in lint['checks'])==1
assert all(c['timeout_seconds']<=120 for c in lint['commands'])
oldmanifest=json.loads(subprocess.check_output(['git','show','b94e043:config/rtl_checks.json']))
assert len(manifest['lint_designs'])==len(oldmanifest['lint_designs'])+1
for old,new in zip(oldmanifest['lint_designs'],manifest['lint_designs']):
    if old['name']=='basys3_board_shell':
        assert new['top']=='basys3_diagnostic_top' and new['sources']==['fpga/basys3/diagnostic_top.sv']
    else:assert old==new
# Compiler artifacts are found from their recorded names, not a guessed cwd.
elf=next(harness.inside(n) for n in soc['artifacts'] if n.endswith('/compiler/soc.elf'))
raw,segments,symbols=parse_elf(elf.read_bytes());assert words(raw).encode()==harness.inside('fpga/basys3/soc_boot.mem').read_bytes()
retirements=0;bootcycles=0
for boot in soc['boots']:
    summary=check_trace(harness.inside(boot['trace']).read_text(),raw,symbols,boot['divider']);assert summary==boot['summary']
    retirements+=sum(e['retirements'] for e in summary['epochs']);bootcycles+=summary['cycles']
assert {b['divider'] for b in soc['boots']}=={8,868} and len(soc['boots'])==3
assert soc['corrupt_rom_diagnostic'].startswith('SOC_DMEM_RESPONSE cycle=39')
for run in soc['fabric_runs']:
    name=next(n for n in soc['artifacts'] if n.endswith('/fabric-'+str(run['seed'])+'.txt'))
    rows=[[int(x,16) for x in line.split()] for line in harness.inside(name).read_text().splitlines()]
    assert len(rows)==run['cycles'] and all(len(r)==32 for r in rows)
    assert all((offset,mask) in {(r[7]%4,r[10]) for r in rows if r[6] and r[7]//4==base//4} for base in (0x40,0x10040,0x10000000,0x10000020,0x10000100) for offset in range(4) for mask in range(16))
    assert any(r[7]==0x10000 and r[8] and r[11]==0 for r in rows) and run['canceled']==[1,2]
config=harness.read(harness.inside('config/fpga_build.json'));validate_xpr(harness.inside('RV32I_Edge_SoC.xpr').read_text(),config)
assert config['design_scope']=='integrated_soc_initial_fault_halt_EEI' and config['memory_files']==['fpga/basys3/soc_boot.mem']
with zipfile.ZipFile(harness.inside('evidence/prepare/T031-before-integration/inputs.zip')) as z:
    meta=harness.read(harness.inside('evidence/prepare/T031-before-integration/manifest.json'))
    for name,digest in meta['inputs'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
    original=z.read('fpga/basys3/top.sv').decode().replace('\r\n','\n')
    assert harness.inside('fpga/basys3/diagnostic_top.sv').read_text()==original.replace('module basys3_top (','module basys3_diagnostic_top (')
integration=harness.read(harness.inside('evidence/toolchain_runs/soc-project-integration-20261107T205550441295Z.json'))
assert integration['status']=='FAIL' and integration['project_manifest_matches']
assert integration['commands'][0]['exit_code']==0 and integration['commands'][0]['stdout'].count('WARNING:')==77
for name,digest in integration['source_sha256'].items():
    assert sha(harness.inside(name))==digest,name;sources[name]=digest
for name,digest in integration['artifacts'].items():artifact(name,digest)
archives={}
for p in harness.inside('evidence/failed_sources/T031').rglob('manifest.json'):
    d=harness.read(p);mapping=d.get('inputs',d.get('source_sha256'))
    if mapping is None:raise ValueError('Unknown failure archive schema '+str(p))
    with zipfile.ZipFile(p.parent/'inputs.zip') as z:
        for name,digest in mapping.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
    archives[p.relative_to(harness.ROOT).as_posix()]=sha(p)
baseline=harness.read(harness.inside('evidence/prepare/T031-baseline-2026-11-06.json'))
allowed=set(baseline['expected_existing_changes'])|{'scripts/test_board_checks.py','scripts/test_fpga_build.py'}
preserved={}
for name,digest in baseline['source_sha256'].items():
    if name in allowed:continue
    assert sha(harness.inside(name))==digest,name;preserved[name]=digest
oldstate=json.loads(subprocess.check_output(['git','show','b94e043:.harness/state.json']))
for key in ('owner_reviews','start_approvals','owner_skips','daily_claims','daily_exceptions'):
    assert state.get(key)==oldstate.get(key),key
for name in ('docs/daily/2026-11-06_technical.md','docs/daily/2026-11-06_zh-CN.md'):
    prior=subprocess.check_output(['git','show','b94e043:'+name]).decode();assert harness.inside(name).read_text().startswith(prior)
registry=harness.read(harness.inside('.harness/checks.json'));oldregistry=json.loads(subprocess.check_output(['git','show','b94e043:.harness/checks.json']))
oldcommands=oldregistry['regress']['commands'];assert registry['regress']['commands'][:-1]==oldcommands
assert registry['regress']['commands'][-1]==['{python}','-B','scripts/verify.py','test-soc']
assert len(list(harness.inside('docs/daily').glob('2026-11-07_*.md')))==2
with zipfile.ZipFile(harness.inside('evidence/prepare/T031-registry-before-LF.zip')) as z:
    raw_registry=z.read('.harness/checks.json')
    assert b'\r\n' in raw_registry and json.loads(raw_registry)==registry
    assert b'\r' not in harness.inside('.harness/checks.json').read_bytes()
for name in ('.harness/checks.json','scripts/test_rtl_checks.py','scripts/test_fpga_build.py'):
    sources[name]=sha(harness.inside(name))
audit={'task':'T031','receipt':receipt,'tool_receipts':{n:sha(harness.inside(n)) for n in tools},'source_sha256':sources,'artifacts':artifacts,'preserved':preserved,'archives':archives,
       'additional_explained_existing_changes':['scripts/test_board_checks.py','scripts/test_fpga_build.py'],
       'counts':{'tools':len(tools),'sources':len(sources),'artifacts':len(artifacts),'preserved':len(preserved),'positive_boot_cycles':bootcycles,'positive_retirements':retirements,'decoded_uart_bytes':36,'fabric_cycles':sum(r['cycles'] for r in soc['fabric_runs']),'native_integration_warnings_retained':77},
       'limitations':['formal T023 skipped/NOT RUN','full FPGA synthesis/implementation/timing/power/CDC/bitstream NOT RUN','hardware/ASIC NOT RUN','open_project catalog warnings retained FAIL']}
harness.atomic(harness.inside('evidence/t031-final-audit-2026-11-07.json'),audit);print(json.dumps(audit['counts']))
