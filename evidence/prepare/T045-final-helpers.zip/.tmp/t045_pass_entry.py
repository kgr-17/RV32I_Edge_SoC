import json,sys
sys.path.insert(0,'scripts')
import harness,report

audit=harness.read(harness.inside('evidence/prepare/T045-final-audit-2026-11-07.json'))
assert audit['status']=='PASS'
technical='''## T045 completed: approved v0.3 implementation and simulation acceptance

Authoritative attempt 2: {attempt}. All five gates PASS, exit 0:
python -B scripts/verify.py lint; python -B scripts/verify.py test-interrupts;
python -B scripts/verify.py regress; git diff --check; git diff --cached --check.
Strict lint passed 53 checks/28 native commands. Regression passed all 28 indexed
targets in {seconds:.3f}s; original 27 commands remain the unchanged prefix.
Two fresh IRQ suites each passed 119 checks/59 commands, with seeds 1/20261107.
Production top at divisor 868 passed 179302 cycles, two boots of 2895 retirements
each, 20 independently decoded IRQ PASS CRLF bytes and persistent RAM counter
1->2. Nine positive runs per suite include random waits, source cancellation,
six reset-aborted states and fault-before-IRQ priority. Four unit RTL mutants,
an actual wrong-return-PC core, malformed/wrong vectors/traces and corrupt ROM
were rejected at their intended checks. Four CSR tests, seven IRQ oracle tests,
two dispatch, five budget, 43 harness and eight native process tests also passed.
No formal proof or certification is inferred from finite simulation.

Implementation: csr_file atomically commits the approved 14-CSR subset with
reset > trap > MRET > software-write priority. trap_control drains and rechecks
the level, saving the latest retired continuation. The pipeline serializes six
CSR operations and MRET; precise exceptions kill younger work and drain stale
fetches. Timer CTRL bit 2 enables synchronous machine-external IRQ cause 11;
bit 1 keeps its existing reload meaning. Separate trap and CSR observations
extend the normal core to 52 ports. Core/SoC default to legacy mode, while the
canonical Basys3 top enables the approved mode and separate irq_boot.mem.
Production and all simulations use the normal interfaces; exact disabled probe
specializations remain guarded and recorded. No warning filter was added.

Main source changes: rtl/core/csr_file.sv, trap_control.sv, pipeline_cpu.sv,
decoder.sv, rv32_pkg.sv; rtl/peripherals/timer.sv; rtl/soc/edge_soc.sv and
soc_fabric.sv; fpga/basys3/top.sv. Verification adds independent CSR and full
ISA/bus/peripheral/serial models, seven testbench snapshots, three lint probes,
scripts/interrupt_checks.py, interrupt_firmware.py and interface-contract check.
sw/interrupt_smoke.S uses the existing boot/linker, saves nested trap frames and
demonstrates timer IRQ/MRET. Registry/manifests/source lists include these files;
existing benches only bind new ports or select their original legacy image.
Config/XPR source graph includes the two RTL files and additional image; XPR
adds 20 lines with no deletion. Recoverable before-image is in
evidence/prepare/T045-before-integration/. Original kit, XDC, prior images,
boot/linker, approved architecture and interrupt specification stay unchanged.

Engineering infrastructure: independent regression targets run with two workers,
retain registered indices and flush complete results. Ordinary checks remain
sequential. Each native command uses its own build/tmp directory. The existing
600s aggregate and 120s native limits and descendant timeout cleanup remain.
First final attempt and all preparatory failures are retained, including native
XSim startup failure with unknown cause. The unique temporary directory change
is isolation evidence, not proof of that failure's cause. Attempt 2 succeeds
without clearing attempt 1; state records 2 attempts and no active task.

Final audit evidence/prepare/T045-final-audit-2026-11-07.json recursively binds
{tools} tool receipts, {sources} source hashes and {artifacts} artifact hashes;
all are current to this attempt. It also checks exact regression command prefix,
source archive hashes, baseline preservation, report append-only history and
unchanged owner approvals/skips/legacy claims. A copy of the audit helper is
retained for replay. Source-only Vivado integration remains explicitly FAIL for
installed board catalog warnings, with exact manifest PASS and idempotent XPR
hash checked separately. This does not establish a warning-free full FPGA build.

Git baseline f9d05e0 records T044 owner approval; reviewed proposal 80bd35e and
T031 66bfa46 remain in history. Commit this inspected T045 package locally after
the final diff/index review; do not push. Mandatory progress is 34 completed plus
one owner-skipped task out of 41. T023 formal remains NOT RUN and must be disclosed
in final review. Full target synthesis/place/route/timing/power/CDC/bitstream,
physical-board tests and ASIC evidence remain NOT RUN.

Next session: read this handoff and all AGENTS startup files, run daily
--supervised, inspect Git and recover any active task. T045 is complete; do not
rerun finish or reset attempts. Query next; prepare the hashed T043 plan only,
then obtain the owner's explicit T043 execution authorization before authorize/
begin or any full target build. Do not approve final T043 review or program a
physical FPGA on the owner's behalf. Runtime remains unrestricted/never and is
not a sandbox; no unattended runs, downloads, installs, global edits or scheduling.
Versions unchanged: Python 3.9.13, Git 2.48.1.windows.1, tzdata 2026.2 and
Vivado/XSim 2025.2 SW 6299465, with pinned actual GNU compiler components.
'''.format(attempt=audit['attempt'],seconds=audit['regression_wall_seconds'],tools=len(audit['tool_receipts']),sources=len(audit['source_sha256']),artifacts=len(audit['artifacts']))
zh='''## T045完成：中断、异常与CSR实现通过正式仿真验收

第二次最终验收的五项门禁全部通过：严格综合lint、中断专项、完整28目标回归及两项
空白检查。原有27条回归命令保留，中断专项在直接门禁和完整回归中各执行一次，均
通过119项检查和59条原生命令。两组固定种子可复现。生产分频868下，真实Basys3
顶层通过179302周期、两次各2895条退休指令，串口正确输出两次IRQ PASS，温复位
后保留RAM计数从1变为2。随机总线等待、中断撤销、六个复位取消点和异常/中断
冲突均覆盖；故意植入的错误RTL、错误返回PC和坏镜像均被独立检查器捕获。

关键概念：CSR是处理器控制状态；MRET恢复异常前执行。精确异常要求旧指令已完成、
新指令不产生多余副作用。中断到来时先排空流水线，再重新确认中断仍然有效，以最后
退休指令的后继PC返回。同步异常优先于正在排空的中断。定时器CTRL第2位开启IRQ，
第1位继续用于原有自动重装；这里采用机器外部中断原因11。软件显式保存嵌套异常
现场。旧模式及原有固件仍保留，默认板级顶层启用您批准的新模式和独立启动镜像。

严格lint通过53项检查；进程临时目录隔离、并发结果保存、超时清理等基础设施也已
验证。首次验收失败及准备过程中的失败均保留，未清除次数、屏蔽警告或提高超时。
首次XSim启动失败原因仍未知，不能把目录隔离解释成已证明的根因修复。第二次验收
成功。最终审计核对本次工具日志、源码与产物哈希、旧文件基线和审批记录。工程集成
的安装板卡库警告仍记FAIL，源清单吻合单独记PASS。原工程、约束和旧镜像可恢复。

请重点查看docs/INTERRUPT_REPORT.md中的接口、复位/优先级、兼容参数及测试证据。
工程关键词：CSR、MRET、precise exception、pipeline drain、interrupt pending、
retirement trace、W1C、cold boot、warm reset、mutation testing。下一任务T043将
对完整SoC做综合、布局布线、时序、功耗与bitstream证据；必须先获得您的执行授权。
当前尚无这些整机结果，也没有实板烧写。形式证明T023仍按您的要求跳过且NOT RUN，
最终评审必须保留这一缺口。强制任务进度34项完成、1项跳过，共41项。

今日仍只追加两份日报，本地Git提交保存源码与证据。新会话先读最新技术交接，再运行
受监督循环并检查Git。当前运行时不受沙箱限制，不允许无人值守任务、下载、全局
设置更改、推送或自动烧写；T043执行与最终人工评审仍分别保留审批边界。
'''
entry={'technical':technical,'zh-CN':zh}
harness.atomic(harness.inside('evidence/report_entries/t045-2026-11-07-complete.json'),entry)
print(report.generate(entry))
for n in ['docs/INTERRUPT_REPORT.md','evidence/daily/T045.md']:
 p=harness.inside(n);harness.atomic_text(p,p.read_text(encoding='utf-8')+'\n'+technical)
