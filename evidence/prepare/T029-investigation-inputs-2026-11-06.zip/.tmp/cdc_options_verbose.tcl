puts "CDC_OPTIONS_VERSION=[version -short]"
puts [help report_cdc]
puts [help get_cdc_violations]
puts [help set_input_delay]
puts "CDC_OPTIONS_PASS"
