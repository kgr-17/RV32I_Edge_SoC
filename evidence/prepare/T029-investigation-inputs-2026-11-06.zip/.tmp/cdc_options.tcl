puts "CDC_OPTIONS_VERSION=[version -short]"
puts "CDC_COMMANDS=[lsort [info commands *cdc*]]"
help report_cdc
if {[llength [info commands get_cdc_violations]]} {help get_cdc_violations}
help set_input_delay
puts "CDC_OPTIONS_PASS"
