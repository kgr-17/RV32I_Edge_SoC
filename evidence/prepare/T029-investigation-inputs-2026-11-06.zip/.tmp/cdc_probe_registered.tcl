if {$argc!=1} {error "CDC_PREP_ARGUMENTS"}
set f [open [lindex $argv 0] r];set sources [split [string trim [read $f]] "\n"];close $f
read_verilog -sv $sources
synth_design -top cdc_registered_probe -part xc7a35tcpg236-1 -flatten_hierarchy none
create_clock -name core_clk -period 10.000 [get_ports clk_i]
create_clock -name external_model -period 13.000 [get_ports clk_external_i]
set ext_ports [get_ports -filter {DIRECTION == IN && NAME != clk_i && NAME != clk_external_i}]
if {[llength $ext_ports]!=18} {error "CDC_EXTERNAL_PORT_COUNT"}
set_input_delay -clock external_model -min 0.000 $ext_ports
set_input_delay -clock external_model -max 0.000 $ext_ports
set_output_delay -clock core_clk -min 0.000 [all_outputs]
set_output_delay -clock core_clk -max 0.000 [all_outputs]
set_clock_groups -asynchronous -group [get_clocks core_clk] -group [get_clocks external_model]
check_timing -verbose -file timing_checks.rpt
report_cdc -details -all_checks_per_endpoint -no_waiver -file cdc.rpt
set objects [get_cdc_violations]
set f [open cdc_objects.txt w]
foreach v $objects {
    puts $f [list violation $v]
    foreach p [lsort [list_property $v]] {puts $f [list property $p [get_property $p $v]]}
}
close $f
write_xdc effective_analysis.xdc
puts "CDC_PREP_REPORT_CAPTURED objects=[llength $objects]"
