from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path('scripts').resolve()))
import harness,rtl_checks
c=rtl_checks.Checks('cdc-report-preparation',task='T029',scope='Actual2025.2 report capture/inspection only; not a CDC task pass')
sources=['rtl/peripherals/reset_sync.sv','rtl/peripherals/input_sync.sv','rtl/peripherals/uart_rx.sv','dv/cdc/cdc_probe.sv','.tmp/cdc_probe_prepare.tcl']
c.result['source_sha256']={n:hashlib.sha256(harness.inside(n).read_bytes()).hexdigest() for n in sources}
work=c.base/'probe';work.mkdir();source_list=work/'sources.txt'
harness.atomic_text(source_list,'\n'.join(str(harness.inside(n)) for n in sources if n.endswith('.sv'))+'\n')
r=c.vendor('vivado',['-mode','batch','-nolog','-nojournal','-notrace','-source',str(harness.inside(sources[-1])),'-tclargs',str(source_list)],work,60)
c.result['artifacts']={p.relative_to(harness.ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in work.glob('*') if p.is_file()}
ok=rtl_checks.successful(r) and 'CDC_PREP_REPORT_CAPTURED objects=' in r['stdout']
c.result['checks'].append({'name':'Report capture only, not safety classification','status':'PASS' if ok else 'FAIL','command_index':0})
c.result['status']='PASS' if ok else 'FAIL';c.save();print(json.dumps({'status':c.result['status'],'receipt':c.path.relative_to(harness.ROOT).as_posix()}));sys.exit(0 if ok else 1)
