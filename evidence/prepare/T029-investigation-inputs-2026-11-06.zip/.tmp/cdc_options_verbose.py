from pathlib import Path
import hashlib,sys
sys.path.insert(0,str(Path('scripts').resolve()))
import harness,rtl_checks
c=rtl_checks.Checks('cdc-options-verbose',task='T029',scope='Read-only local Vivado2025.2 Tcl option discovery, no hardware design/build')
c.result['source_sha256']={'.tmp/cdc_options_verbose.tcl':hashlib.sha256(harness.inside('.tmp/cdc_options_verbose.tcl').read_bytes()).hexdigest()}
r=c.vendor('vivado',['-mode','batch','-nolog','-nojournal','-notrace','-source',str(harness.inside('.tmp/cdc_options_verbose.tcl'))],c.base/'options',45)
c.require(rtl_checks.successful(r,'CDC_OPTIONS_PASS') and 'Vivado v2025.2' in r['stdout'],'Installed2025.2 CDC options',r)
c.result['status']='PASS';c.save();print(c.path)
