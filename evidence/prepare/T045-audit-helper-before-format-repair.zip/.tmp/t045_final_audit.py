import collections, datetime as dt, hashlib, json, pathlib, subprocess, sys, zipfile
sys.path.insert(0,'scripts')
import harness, closure_checks, rtl_checks, fpga_build

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def path(n): return fpga_build.project_path(n)
def git(*args): return subprocess.check_output(['git',*args],cwd=harness.ROOT)
plan,state=harness.load()
journal_name=state['receipts']['T045']; journal=harness.read(path(journal_name))
assert journal['attempt']==state['attempts']['T045']==2
assert state['task_states']['T045']=='completed' and state['active'] is None
assert journal['stage']=='finished',journal['stage']
registry=harness.read(path('.harness/checks.json'))
task=next(t for t in plan['tasks'] if t['id']=='T045')
closure_checks.passed_prefix(journal['commands'],task['verification_commands']+[['git','diff','--check'],['git','diff','--cached','--check']])
since=dt.datetime.fromisoformat(journal['commands'][0]['started_utc'])
manifest=rtl_checks.load_manifest();pins={k:v for k,v in manifest.items() if k.endswith('_version') or k=='vivado_sw_build'}
tools={};sources={};artifacts={}

def artifact(n,h):
 p=path(n);assert sha(p)==h,('artifact',n)
 artifacts[p.relative_to(harness.ROOT).as_posix()]=h
def tool(n):
 n=path(n).relative_to(harness.ROOT).as_posix()
 assert n.startswith('evidence/toolchain_runs/') and n.endswith('.json'),n
 if n in tools:return
 r=harness.read(path(n));closure_checks.validate_tool(r,since,pins,lambda n:sha(path(n)))
 tools[n]=r;sources.update(r.get('source_sha256',{}));visit(r)
def visit(o):
 if isinstance(o,list):
  for v in o:visit(v)
 elif isinstance(o,dict):
  if isinstance(o.get('evidence'),str):tool(o['evidence'])
  if isinstance(o.get('path'),str) and isinstance(o.get('sha256'),str):
   artifact(o['path'],o['sha256'])
   if path(o['path']).relative_to(harness.ROOT).as_posix().startswith('evidence/toolchain_runs/'):tool(o['path'])
  for n,h in o.get('artifacts',{}).items():artifact(n,h)
  for k in ('vector','waveform'):
   if k+'_sha256' in o:artifact(o.get(k+'_path',o.get(k)),o[k+'_sha256'])
  if isinstance(o.get('stdout'),str):
   for v in closure_checks.metadata_objects(o['stdout']):visit(v)
  for k,v in o.items():
   if k!='stdout' and isinstance(v,(list,dict)):visit(v)
visit(journal['commands'])
reg=next(r for r in journal['commands'] if r['argv'][-1]=='regress')
rows=closure_checks.metadata_objects(reg['stdout']);assert len(rows)==28
rows.sort(key=lambda r:r['registered_command_index'])
assert [r['registered_command_index'] for r in rows]==list(range(28))
closure_checks.passed_prefix(rows,registry['regress']['commands'])
old_registry=json.loads(git('show','f9d05e0:.harness/checks.json'))
assert registry['regress']['commands'][:27]==old_registry['regress']['commands']
counts=collections.Counter(r['profile'] for r in tools.values())
assert closure_checks.PROFILES<=set(counts),counts
assert counts['interrupts']==2
irq_runs={n:r for n,r in tools.items() if r['profile']=='interrupts'}
expected_labels={'fast-1','fast-20261107','waits-1','waits-20261107','aborts-1','aborts-20261107','production','priority-1','priority-20261107'}
for n,r in irq_runs.items():
 assert len(r['checks'])==119 and len(r['commands'])==59,(n,len(r['checks']),len(r['commands']))
 assert len(r['boots'])==9 and {b['label'] for b in r['boots']}==expected_labels
 assert len(r['unit_runs'])==4
 assert {a['seed'] for a in r['unit_runs']}=={1,20261107}
 assert all(b['summary']['uart_bytes']==20 for b in r['boots'])
 assert all(len(b['summary']['epochs'])==2+b['aborted_epochs'] for b in r['boots'])
 prod=next(b for b in r['boots'] if b['label']=='production')
 assert prod['divider']==868 and prod['summary']['cycles']==179302
 assert [e['retirements'] for e in prod['summary']['epochs']]==[2895,2895]
 for command in r['commands']:
  t=path(command['temporary_directory']);assert harness.inside('build/tmp') in t.parents
lint=next(r for r in tools.values() if r['profile']=='lint')
expected={'pipeline_cpu_lint_top':['RV32_CORE_LEGACY_PORTS'],'timer':['RV32_TIMER_LEGACY_PORTS']}
assert len(lint['lint_inputs'])==len(manifest['lint_designs'])+1
for row in lint['lint_inputs']:
 assert row['defines']==expected.get(row['top'],[]),row
assert all(sha(path(n))==h for n,h in sources.items())
old_state=json.loads(git('show','f9d05e0:.harness/state.json'))
for k in ('owner_reviews','owner_skips','start_approvals','enabled_optional_ids','daily_claims','daily_exceptions'):
 assert state[k]==old_state[k],k
assert state['owner_skips'].keys()=={'T023'} and state['task_states']['T023']=='skipped'
assert state['attempts']['T023']==old_state['attempts']['T023'] and state['receipts']['T023']==old_state['receipts']['T023']
allowed=set('''.harness/checks.json
.harness/state.json
README.md
RV32I_Edge_SoC.xpr
config/fpga_build.json
config/rtl_checks.json
docs/BACKLOG.json
docs/FPGA_PPA.md
docs/SOC_BOOT.md
docs/daily/2026-11-07_technical.md
docs/daily/2026-11-07_zh-CN.md
dv/assertions/tb_assertions.sv
dv/coverage/tb_coverage.sv
dv/integration/tb_backpressure.sv
dv/integration/tb_control.sv
dv/integration/tb_isa_complete.sv
dv/integration/tb_load_use.sv
dv/integration/tb_mmio.sv
dv/integration/tb_soc_board.sv
dv/integration/tb_soc_boot.sv
dv/integration/tb_soc_fabric.sv
dv/lint/pipeline_cpu_lint_top.sv
dv/random/tb_random.sv
dv/random/tb_stress.sv
fpga/basys3/top.sv
rtl/core/decoder.sv
rtl/core/pipeline_cpu.sv
rtl/core/rv32_pkg.sv
rtl/peripherals/timer.sv
rtl/soc/edge_soc.sv
rtl/soc/soc_fabric.sv
scripts/project_integration.py
scripts/rtl_checks.py
scripts/test_rtl_checks.py
scripts/test_tool_runner.py
scripts/tool_runner.py
scripts/verify.py
scripts/vivado_lint.tcl'''.splitlines())
baseline=harness.read(path('evidence/prepare/T045-baseline-2026-11-07.json'))['source_sha256']
changed={n for n,h in baseline.items() if sha(path(n))!=h}
assert changed<=allowed,changed-allowed
assert not git('diff','--name-only','--diff-filter=D')
for suffix in ('technical','zh-CN'):
 n='docs/daily/2026-11-07_'+suffix+'.md'
 old=git('show','f9d05e0:'+n).decode('utf-8').replace('\r\n','\n')
 assert path(n).read_text(encoding='utf-8').startswith(old)
assert {p.name for p in path('docs/daily').glob('2026-11-07*')}=={'2026-11-07_technical.md','2026-11-07_zh-CN.md'}
archives={}
for folder in list(path('evidence/failed_sources/T045').iterdir())+[path('evidence/prepare/T045-before-integration'),path('evidence/prepare/T045-passed-before-priority')]:
 p=folder/'manifest.json';z=folder/'inputs.zip'
 if not p.is_file() or not z.is_file():continue
 d=harness.read(p)
 with zipfile.ZipFile(z) as f:
  for n,h in d.get('inputs',d.get('source_sha256',{})).items():
   assert hashlib.sha256(f.read(n)).hexdigest()==h,(z,n)
 if 'receipt_sha256' in d:assert sha(path(d['receipt']))==d['receipt_sha256']
 archives[p.relative_to(harness.ROOT).as_posix()]={'zip_sha256':sha(z),'manifest_sha256':sha(p),'input_files':len(d.get('inputs',d.get('source_sha256',{})))}
integration=harness.read(path('evidence/toolchain_runs/soc-project-integration-20261108T023432195703Z.json'))
assert integration['status']=='FAIL' and integration['project_manifest_matches'] is True
xprh=sha(path('RV32I_Edge_SoC.xpr'))
assert all(h==xprh for n,h in integration['artifacts'].items() if n.endswith('.xpr'))
out={'status':'PASS','scope':'Current T045 attempt exact gates, recursive receipts/artifacts/source hashes and baseline preservation; no new functional or formal claim',
 'attempt':journal_name,'attempt_sha256':sha(path(journal_name)),'checked_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
 'script_sha256':sha(path('.tmp/t045_final_audit.py')),'profile_counts':dict(sorted(counts.items())),
 'tool_receipts':{n:sha(path(n)) for n in tools},'source_sha256':sources,'artifacts':artifacts,
 'regression_targets':len(rows),'regression_wall_seconds':(dt.datetime.fromisoformat(journal['commands'][3]['started_utc'])-dt.datetime.fromisoformat(reg['started_utc'])).total_seconds(),'irq_runs':list(irq_runs),
 'baseline_unchanged_files':len(baseline)-len(changed),'baseline_modified_files':sorted(changed),'preserved_archives':archives,
 'formal':'T023 owner-skipped / NOT RUN','full_target_implementation':'NOT RUN','physical_fpga':'NOT RUN','asic':'NOT RUN'}
harness.atomic(path('evidence/prepare/T045-final-audit-2026-11-07.json'),out)
print(json.dumps({k:v for k,v in out.items() if k not in ('source_sha256','artifacts','tool_receipts','preserved_archives','baseline_modified_files')}))
