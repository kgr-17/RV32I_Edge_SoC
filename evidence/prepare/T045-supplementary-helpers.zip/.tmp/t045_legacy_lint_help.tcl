puts [help -syntax read_verilog]
puts [help -syntax synth_design]
exit 0
