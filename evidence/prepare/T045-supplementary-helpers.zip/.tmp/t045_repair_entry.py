import sys
sys.path.insert(0,'scripts')
import harness, report

technical = '''## T045 first final attempt failed; bounded second attempt prepared

Attempt 1, evidence/runs/T045/attempt-1-20261108T015654747556Z.json:
lint FAIL(1), test-interrupts PASS(0), regress FAIL(1), both whitespace gates PASS(0).
All 27 preceding regression targets passed. The new IRQ target failed because
the production XSim process exited 4294967295 after 0.781s with empty stdout and
stderr and no waveform. This is an actual native failure; root cause remains
unknown. The separate earlier IRQ gate passed 119 checks/59 native commands.
Regression completed all 28 indexed targets in 537.997524s under the unchanged
600s command cap. Attempt-1 sources (200 files), manifest, journal and hashes are
retained in evidence/failed_sources/T045/attempt-1/. One attempt consumed; two
remain. Resume did not reopen or reset the attempt counter.

Strict synthesis exposed unused constant IRQ/observation logic in disabled
configurations. Enabled-only observation registers now use a generate branch;
legacy observations are constant zero. Exact whitelisted legacy lint definitions
omit only inactive IRQ boundary ports in the two disabled probes. Production,
enabled probes and every simulation use the full normal interface without these
definitions. Both native source guards reject an enabled feature combined with
the legacy-port specialization. No warning filters or diagnostic policies changed.
Native Vivado synth_design -help confirmed -verilog_define; read_verilog has no
such option. Supplementary repair receipt disabled-lint-repair-20261108T022124252206Z
PASS 9 checks/5 commands, including both default probes, enabled CPU, wrong-scope
Tcl rejection and enabled-feature source-guard rejection. All 20 lint-policy tests
and all 8 process-runner tests pass. Existing descendant timeout cleanup remains.

Each native command now gets a unique directory under build/tmp and records it
as temporary_directory; TMP/TEMP/TMPDIR are per child process. This prevents
shared fixed temporary filenames. It is not proof of the XSim failure's cause.
The first implementation lacked the parent directory; two preparations failed
before EDA launch and their 20 inputs were archived before the mkdir repair.
Enabled cold/warm boot then passed in interrupt-boot-preparation-20261108T022134468028Z.
Runner tests are added to the required IRQ gate. No timeout cap increased.

Source-only integration soc-project-integration-20261108T023432195703Z still FAIL
for the installed board catalog warnings; project_manifest_matches is true and
the second apply leaves the XPR unchanged. No full synthesis/implementation,
bitstream or programming was invoked. Approved specifications, legacy firmware,
XDC and original kit are retained. Temporary helper discovery used a nonexistent
harness.write API; Python exited 1 before any file write, then atomic was used.

Next: inspect current diff/contract, finish T045 for fresh attempt 2, audit exact
current sources and recursive receipts/artifacts, append these same two dated
reports and commit inspected files if all gates pass. If another failure occurs,
retain its complete input snapshot before repair and observe the three-attempt
limit. No automatic owner approval or task reopening. T043 execution requires
separate owner authorization after its concrete plan is prepared. T023 formal
remains owner-skipped/NOT RUN. Full target timing/PPA/CDC, hardware and ASIC remain
NOT RUN. This runtime is unrestricted; attended execution only. Python3.9.13,
Git2.48.1.windows.1, tzdata2026.2, Vivado/XSim2025.2 SW6299465 unchanged.
'''
zh = '''## T045首次最终验收失败，修复后准备第二次验收

首次验收的lint和全回归失败，中断专项及两项空白检查通过。原有27个回归目标全部
通过；新增中断目标中的生产分频XSim进程启动失败，退出码4294967295，没有输出或
波形，原因仍未知。此前单独运行中断专项通过119项检查、59条原生命令。失败日志和
当时200个输入文件均已保存；已用一次验收预算，还剩两次，未重置记录。

综合发现旧模式中不用的中断端口和观察寄存器。现已按参数分支隔离观察状态，并仅为
两个旧模式lint探针使用严格限定的端口宏；生产设计、启用模式和所有仿真仍用完整
接口。宏与启用功能同时使用会被工具拒绝。没有屏蔽警告，也没有放宽超时或验收。
修复专项通过9项检查、5条命令；20项lint策略及8项进程管理测试通过。

每条原生命令现在拥有工程内独立临时目录，避免并行命令使用同名临时文件；这并不
证明它就是XSim失败的原因。初版缺少父目录，失败证据已保留后修复。真实SoC冷启动
和温复位启动再次通过。进程测试加入正式中断门禁，保留超时清理子进程的原有要求。
工程源清单吻合，重复集成未改变XPR；安装板卡库警告仍如实记录为FAIL。

下一步重新运行全部验收，审计本次证据与源码哈希，通过后本地提交。T043整机FPGA
实现仍需您单独授权；不会自行授权或烧写。形式证明仍跳过且NOT RUN，整机布线时序、
功耗、完整CDC、实板和ASIC尚未验证。今天仍只追加两份日报。当前会话无沙箱限制，
仅在有人监督时执行，不安排无人值守任务，不下载工具或改变全局设置。
'''
entry={'technical':technical,'zh-CN':zh}
harness.atomic(harness.inside('evidence/report_entries/t045-2026-11-07-repair.json'),entry)
print(report.generate(entry))
for name in ['docs/INTERRUPT_REPORT.md','evidence/daily/T045.md']:
 p=harness.inside(name);harness.atomic_text(p,p.read_text(encoding='utf-8')+'\n'+technical)
