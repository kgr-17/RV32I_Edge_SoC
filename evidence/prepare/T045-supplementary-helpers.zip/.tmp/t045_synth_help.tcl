help -syntax synth_design
exit 0
