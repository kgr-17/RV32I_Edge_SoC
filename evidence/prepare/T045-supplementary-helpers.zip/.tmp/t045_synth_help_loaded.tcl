load_feature synth
help -syntax synth_design
exit 0
