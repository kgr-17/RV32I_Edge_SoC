synth_design -help
exit 0
