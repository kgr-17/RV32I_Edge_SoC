# Add the inspected T025 diagnostic shell to the EXISTING project, idempotently.
# No synthesis/implementation, IP, bitstream, hardware server or programming.
if {[catch {
    set root [file normalize [file join [file dirname [info script]] ../..]]
    set xpr [file join $root RV32I_Edge_SoC.xpr]
    if {![file isfile $xpr]} {error "PROJECT_MISSING"}
    # The inspected original XPR serialized an empty board preset. Remove that
    # empty field before open_project: this direct-part project uses no preset.
    # A nonempty owner-selected preset is NEVER rewritten by this normalizer.
    set stream [open $xpr r]
    set text [read $stream]
    close $stream
    if {![string match {*<Option Name="Part" Val="xc7a35tcpg236-1"/>*} $text]} {error "TARGET_MISMATCH"}
    set normalized [string map [list "    <Option Name=\"BoardPart\" Val=\"\"/>\n" ""] $text]
    if {$normalized ne $text} {
        set stream [open $xpr w]
        fconfigure $stream -translation crlf
        puts -nonewline $stream $normalized
        close $stream
    }
    open_project $xpr
    if {[get_property PART [current_project]] ne "xc7a35tcpg236-1"} {error "TARGET_MISMATCH"}
    set topfile [file join $root fpga/basys3/top.sv]
    set xdc [file join $root fpga/basys3/basys3.xdc]
    # Inspect every existing entry BEFORE modifying filesets/top. Refuse unknown
    # sources/top rather than replacing owner additions or integrating stale RTL.
    foreach file [get_files -quiet -of_objects [get_filesets sources_1]] {
        if {[file normalize $file] ne $topfile} {error "UNEXPECTED_DESIGN_SOURCE: $file"}
    }
    foreach file [get_files -quiet -of_objects [get_filesets constrs_1]] {
        if {[file normalize $file] ne $xdc} {error "UNEXPECTED_CONSTRAINT_SOURCE: $file"}
    }
    set oldtop [get_property TOP [get_filesets sources_1]]
    if {$oldtop ni {"" basys3_top}} {error "UNEXPECTED_OWNER_TOP: $oldtop"}
    if {[llength [get_files -quiet $topfile]] == 0} {add_files -norecurse $topfile}
    if {[llength [get_files -quiet $xdc]] == 0} {add_files -fileset constrs_1 -norecurse $xdc}
    set_property TOP basys3_top [get_filesets sources_1]
    set_property TOP_AUTO_SET 0 [get_filesets sources_1]
    update_compile_order -fileset sources_1
    close_project
    puts "BOARD_INTEGRATION_PASS"
} detail]} {
    puts stderr "BOARD_INTEGRATION_FAIL: $detail"
    exit 1
}
exit 0
