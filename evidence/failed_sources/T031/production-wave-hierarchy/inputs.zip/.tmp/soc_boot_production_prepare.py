from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path('scripts').resolve()));sys.path.insert(0,str(Path('dv/integration').resolve()))
import harness,rtl_checks,soc_model
from soc_firmware import build
c=rtl_checks.Checks('soc-production-preparation',task='T031',scope='First actual compiled CPU/memory/MMIO boot and independent transcript check; preparation only')
code=1
try:
    manifest=harness.read(harness.inside('config/rtl_checks.json'));c.versions(manifest)
    core=next(d['sources'] for d in manifest['lint_designs'] if d['top']=='pipeline_cpu_lint_top')
    # Keep the verified core source order, discard its unrelated probe top.
    core=[n for n in core if n.startswith('rtl/')]
    rtl=core+['rtl/memory/boot_rom.sv','rtl/memory/data_ram.sv','rtl/peripherals/uart_tx.sv','rtl/peripherals/uart_rx.sv','rtl/peripherals/uart_mmio.sv',
        'rtl/peripherals/input_sync.sv','rtl/peripherals/gpio.sv','rtl/peripherals/timer.sv','rtl/peripherals/reset_sync.sv','rtl/soc/soc_fabric.sv','rtl/soc/edge_soc.sv']
    rtl=list(dict.fromkeys(rtl));sources=rtl+['dv/integration/tb_soc_boot.sv','dv/integration/soc_model.py','sw/soc_smoke.S','scripts/soc_firmware.py','.tmp/soc_boot_production_prepare.py']
    c.result['source_sha256']={n:hashlib.sha256(harness.inside(n).read_bytes()).hexdigest() for n in sources}
    raw,symbols=build(c,c.base/'compiler');work=c.base/'simulation';work.mkdir()
    harness.atomic_text(work/'soc_boot.mem',harness.inside('fpga/basys3/soc_boot.mem').read_text())
    r=c.vendor('xvlog',['--sv']+[str(harness.inside(n)) for n in rtl+['dv/integration/tb_soc_boot.sv']],work,30)
    c.require(rtl_checks.successful(r),'Actual SoC compile',r)
    r=c.vendor('xelab',['work.tb_soc_boot_default','--snapshot','soc','--timescale','1ns/1ps','--debug','typical'],work,45)
    c.require(rtl_checks.successful(r),'Actual SoC elaborate',r)
    tcl=work/'run.tcl';harness.atomic_text(tcl,'log_wave /tb_soc_boot_default/inner/clk /tb_soc_boot_default/inner/rst /tb_soc_boot_default/inner/rx /tb_soc_boot_default/inner/tx /tb_soc_boot_default/inner/leds /tb_soc_boot_default/inner/rv /tb_soc_boot_default/inner/pc /tb_soc_boot_default/inner/fv\nrun all\nquit\n')
    trace=work/'trace.txt';wave=work/'soc.wdb'
    r=c.xsim(['soc','--tclbatch',str(tcl),'--onerror','quit','--onfinish','quit','--testplusarg','SEED=1','--testplusarg','TRACE='+str(trace),'--wdb',str(wave)],work,60,'boot')
    c.require(rtl_checks.successful(r) and 'SOC_RUN_COMPLETE seed=1 divisor=868' in r['stdout'],'Actual SoC run completed',r)
    summary=soc_model.check_trace(trace.read_text(),raw,symbols,868);harness.atomic(work/'summary.json',summary)
    c.require(summary['uart_bytes']==12,'Independent ISA/bus/RAM/warmreset/UART checks')
    c.result['boot_summary']=summary;c.result['status']='PASS';code=0
except (RuntimeError,ValueError,KeyError,OSError,harness.Stop) as exc:c.result.update(status='FAIL',error=str(exc))
c.result['artifacts']={p.relative_to(harness.ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in c.base.rglob('*') if p.is_file()}
c.save();print(json.dumps({'status':c.result['status'],'receipt':c.path.relative_to(harness.ROOT).as_posix(),'error':c.result.get('error')}));sys.exit(code)
