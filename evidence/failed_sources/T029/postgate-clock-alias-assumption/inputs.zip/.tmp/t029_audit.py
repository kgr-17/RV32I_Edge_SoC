from pathlib import Path
import csv,datetime as dt,hashlib,json,re,subprocess,sys,zipfile
sys.path.insert(0,str(Path('scripts').resolve()))
import harness
from closure_checks import metadata_objects
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan,state=harness.load();receipt=state['receipts']['T029'];journal=harness.read(harness.inside(receipt))
assert state['task_states']['T029']=='completed' and state['active'] is None
assert journal['stage']=='finished' and len(journal['commands'])==4 and all(r['status']=='PASS' and r['exit_code']==0 for r in journal['commands'])
tools={};artifacts={};sources={}
def artifact(name,digest):
    p=harness.inside(name);assert sha(p)==digest,name;artifacts[p.relative_to(harness.ROOT).as_posix()]=digest
def visit(obj):
    if isinstance(obj,list):
        for value in obj:visit(value)
    elif isinstance(obj,dict):
        name=obj.get('evidence')
        if isinstance(name,str):name=name.replace('\\','/')
        if isinstance(name,str) and name.startswith('evidence/toolchain_runs/') and name not in tools:
            r=harness.read(harness.inside(name));assert r['status']=='PASS' and r['checks'] and all(c['status']=='PASS' for c in r['checks'])
            assert dt.datetime.strptime(r['started_utc'],'%Y%m%dT%H%M%S%fZ').replace(tzinfo=dt.timezone.utc)>=dt.datetime.fromisoformat(journal['commands'][0]['started_utc'])
            tools[name]=r;visit(r)
        if isinstance(obj.get('path'),str) and isinstance(obj.get('sha256'),str):artifact(obj['path'],obj['sha256'])
        for name,digest in obj.get('artifacts',{}).items():artifact(name,digest)
        for key in ('vector','waveform'):
            if key+'_sha256' in obj:artifact(obj.get(key+'_path',obj.get(key)),obj[key+'_sha256'])
        if isinstance(obj.get('stdout'),str):
            for value in metadata_objects(obj['stdout']):visit(value)
        for key,value in obj.items():
            if key!='stdout' and isinstance(value,(dict,list)):visit(value)
visit(journal['commands']);assert len(tools)==2 and {r['profile'] for r in tools.values()}=={'lint','cdc'}
cdc=next(r for r in tools.values() if r['profile']=='cdc');inventory=[]
for sim,report in zip(cdc['simulations'],cdc['seed_reports']):
    rows=[[int(v,16) for v in line.split()] for line in harness.inside(sim['vector_path']).read_text().splitlines()]
    assert len(rows)==sim['checked_vectors']==1645 and all(len(row)==13 for row in rows)
    release=3;word=[0,0];wide=[0,0];scalar=[0,0];seen=set();pulses=held=0
    for row in rows:
        reset,pulse,phase,data,bit=row[:5]
        assert phase in range(4) and not(reset and pulse);pulses+=pulse;held+=reset
        if reset or pulse:release=3
        pre_reset=release>>1
        assert row[5:9]==[pre_reset,word[1],wide[1],scalar[1]]
        if pre_reset:word=[0,0];wide=[0,0];scalar=[0,0]
        else:word=[data&65535,word[0]];wide=[data,wide[0]];scalar=[bit,scalar[0]]
        release=3 if reset else (release<<1)&3
        assert row[9:13]==[release>>1,word[1],wide[1],scalar[1]];seen.add(wide[1])
    summary=harness.read(harness.inside(report['summary']));assert held==summary['held_reset_edges']==49 and pulses==summary['subcycle_pulses']==36
    assert {1<<bit for bit in range(32)}<=seen and sorted({r[2] for r in rows})==[0,1,2,3]
    inventory.append({'seed':sim['seed'],'cycles':len(rows),'held_reset_edges':held,'subcycle_pulses':pulses,'phases':[0,1,2,3],'observed_one_hot_output_values':32,'widths':[1,16,32]})
structure={};raw_reports={}
for run in cdc['structural_runs']:
    folder=harness.inside(run['cwd']);rows=list(csv.DictReader((folder/'inventory.tsv').read_text().splitlines(),delimiter='\t'))
    rules={r['rule']:r for r in rows};assert len(rows)==3 and all(r['waived']=='0' for r in rows)
    assert all(r['from']=='external_model' and r['to']=='core_clk' for r in rows)
    if run['variant']=='positive':
        assert set(rules)=={'CDC-3','CDC-6','CDC-9'}
        assert all(r['depth']=='2' for r in rows) and rules['CDC-6']['severity']=='Warning'
        assert sum(int(r['endpoints']) for r in rows)==18 and sum(int(r['stages']) for r in rows)==36
        chains=list(csv.DictReader((folder/'chains.tsv').read_text().splitlines(),delimiter='\t'));assert len(chains)==18
        expected={('boundary/switches/meta_q_reg[%d]'%b,'boundary/switches/sync_q_reg[%d]'%b) for b in range(16)}
        expected|={('boundary/receiver/rx_meta_q_reg','boundary/receiver/rx_sync_q_reg'),('boundary/reset_boundary/release_q_reg[0]','boundary/reset_boundary/release_q_reg[1]')}
        assert {(r['first'],r['second']) for r in chains}==expected
        assert all(r['fanout']=='1' and r['first_async'].upper() in ('1','TRUE') and r['second_async'].upper() in ('1','TRUE') for r in chains)
        assert len({r['clock'] for r in chains})==1
        checks=re.findall(r'^\d+\. checking (\S+) \((\d+)\)',(folder/'timing_checks.rpt').read_text(),re.M)
        assert len({name for name,count in checks})==12 and all(int(count)==0 for name,count in checks)
        structure['chains']=chains;structure['timing_check_categories']=12
    elif run['variant']=='missing-rx-attribute':assert 'CDC-2' in rules and rules['CDC-2']['severity']=='Warning'
    elif run['variant']=='input-stage-bypass':assert 'CDC-4' in rules and rules['CDC-4']['severity']=='Critical'
    else:raise AssertionError(run)
    structure[run['variant']]=rows
    for p in folder.iterdir():
        if p.is_file() and p.suffix in ('.rpt','.tsv','.xdc','.txt'):raw_reports[p.relative_to(harness.ROOT).as_posix()]=sha(p)
for r in tools.values():
    for name,digest in r.get('source_sha256',{}).items():assert sha(harness.inside(name))==digest,name;sources[name]=digest
    for command in r['commands']:
        for pattern in ('*.rpt','*.txt','*.tcl','*.args'):
            for p in Path(command['cwd']).glob(pattern):artifacts[p.relative_to(harness.ROOT).as_posix()]=sha(p)
m=harness.read(harness.inside('config/rtl_checks.json'))
for design in m['designs']+m['lint_designs']:
    for name in design['sources']+design.get('memory_files',[]):sources[name]=sha(harness.inside(name))
for name in ('scripts/harness.py','scripts/verify.py','scripts/vivado_lint.tcl'):sources[name]=sha(harness.inside(name))
b=harness.read(harness.inside('evidence/prepare/T029-baseline-2026-11-06.json'));preserved={n:h for n,h in b['source_sha256'].items() if n not in b['expected_existing_changes']}
for name,digest in preserved.items():assert sha(harness.inside(name))==digest,name
prefixes={}
for suffix in ('technical','zh-CN'):
    name='docs/daily/2026-11-06_'+suffix+'.md';old=subprocess.check_output(['git','show',b['baseline_commit']+':'+name])
    assert harness.inside(name).read_bytes().startswith(old);prefixes[name]={'bytes':len(old),'sha256':hashlib.sha256(old).hexdigest()}
text=harness.inside('evidence/daily/T029.md').read_text(encoding='utf-8');snap={}
for p in sorted(harness.inside('evidence/runs/T029').glob('attempt-*.json')):
    run=harness.read(p);number=run['attempt'];prefix=text.split('\n## Verification attempt %d\n'%number)[0]
    assert hashlib.sha256(prefix.encode()).hexdigest()==run['evidence_sha256'];snap[str(number)]={'path':p.relative_to(harness.ROOT).as_posix(),'sha256':run['evidence_sha256'],'content':prefix}
harness.atomic(harness.inside('evidence/prepare/T029-gate-evidence-2026-11-06.json'),snap)
failed=harness.read(harness.inside('evidence/failed_sources/T029/primary-input-report-preparation/manifest.json'));archive=harness.inside('evidence/failed_sources/T029/primary-input-report-preparation/inputs.zip')
assert sha(archive)==failed['archive_sha256']
with zipfile.ZipFile(archive) as z:
    for name,digest in failed['source_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
for name,digest in failed['generated_artifacts'].items():assert sha(harness.inside(name))==digest,name;raw_reports[name]=digest
investigation=harness.read(harness.inside('evidence/prepare/T029-investigation-inputs-2026-11-06.json'));inv_zip=harness.inside(investigation['archive']);assert sha(inv_zip)==investigation['archive_sha256']
with zipfile.ZipFile(inv_zip) as z:
    for name,digest in investigation['source_sha256'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
for name,record in investigation['receipts'].items():assert sha(harness.inside(name))==record['sha256'],name
prep_name='evidence/toolchain_runs/cdc-20261106T223420874717Z.json';prep=harness.read(harness.inside(prep_name));assert prep['status']=='PASS'
for name,digest in prep['source_sha256'].items():assert sha(harness.inside(name))==digest,name
old=json.loads(subprocess.check_output(['git','show',b['baseline_commit']+':.harness/checks.json']));current=harness.read(harness.inside('.harness/checks.json'))
assert current['regress']['commands'][:-1]==old['regress']['commands'] and len(current['regress']['commands'])==25
reports_zip=harness.inside('evidence/prepare/T029-raw-cdc-reports-2026-11-06.zip')
with zipfile.ZipFile(reports_zip,'w',zipfile.ZIP_DEFLATED) as z:
    for name in sorted(raw_reports):z.write(harness.inside(name),name)
audit={'status':'PASS_SCOPED_CDC_WITH_RETAINED_UNWAIVED_GPIO_WARNING','task_receipt':{'path':receipt,'sha256':sha(harness.inside(receipt))},'tool_receipts':{n:sha(harness.inside(n)) for n in tools},
    'source_sha256':sources,'artifacts':artifacts,'actual_vector_inventory':inventory,'actual_cdc_structure':structure,'preserved_tracked_files':preserved,'retained_daily_prefixes':prefixes,
    'failed_preparation_archive_sha256':sha(archive),'failed_inputs':len(failed['source_sha256']),'failed_generated':len(failed['generated_artifacts']),
    'investigation_manifest_sha256':sha(harness.inside('evidence/prepare/T029-investigation-inputs-2026-11-06.json')),'prior_native_preparation':{'path':prep_name,'sha256':sha(harness.inside(prep_name))},
    'raw_reports_archive':{'path':reports_zip.relative_to(harness.ROOT).as_posix(),'sha256':sha(reports_zip),'members':raw_reports},'retained_previous_regression_targets':24,
    'preverification_snapshots_sha256':sha(harness.inside('evidence/prepare/T029-gate-evidence-2026-11-06.json')),
    'scope':'Ideal digital reset/input tests plus synthesized18chain36stage actual CDC fixture. CDC6 Warning retained/notwaived for independent GPIO; sourceFF/13ns clock only in analysis. No atomicword/pulse/debounce/MTBF/fullSoC/routedCDC/full25regression/formal/timing/hardware/ASIC signoff.',
    'counts':{'tools':len(tools),'sources':len(sources),'artifacts':len(artifacts),'preserved':len(preserved),'edge_rows':3290,'chains':18,'stages':36,'retained_cdc_warnings':1,'raw_report_members':len(raw_reports)}}
harness.atomic(harness.inside('evidence/t029-final-audit-2026-11-06.json'),audit);print(json.dumps(audit['counts']))
