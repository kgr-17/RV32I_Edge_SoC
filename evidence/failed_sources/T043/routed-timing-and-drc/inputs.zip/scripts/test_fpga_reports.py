"""Challenge report integrity and timing failure propagation without EDA claims."""
import pathlib
import hashlib
import json
import zipfile
import unittest
import fpga_reports
import harness


class ReportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        folder=harness.inside('dv/fpga/fixtures')
        manifest=json.loads((folder/'manifest.json').read_text())
        assert hashlib.sha256((folder/'reports.zip').read_bytes()).hexdigest()==manifest['zip_sha256']
        with zipfile.ZipFile(folder/'reports.zip') as archive:
            for name,digest in manifest['files'].items():assert hashlib.sha256(archive.read(name)).hexdigest()==digest
            cls.raw=archive.read('synthesis_timing.rpt').decode().replace('\r\n','\n')
            cls.use=archive.read('synthesis_utilization.rpt').decode().replace('\r\n','\n')
    def test_real_synthesis_fixture_retains_negative_estimate(self):
        r=fpga_reports.timing(self.raw,'Synthesized',False)
        self.assertEqual(r['setup']['worst_slack_ns'],-5.559)
        self.assertEqual(r['checks']['no_input_delay'],18)
        self.assertEqual(r['checks']['no_output_delay'],17)
        with self.assertRaisesRegex(ValueError,'TIMING_FAILED'):fpga_reports.timing(self.raw,'Synthesized',True)
    def test_headers_clock_inventory_and_partial_reports_rejected(self):
        mutations=[self.raw.replace('Build 6299465','Build 0'),self.raw.replace('basys3_top','other'),
            self.raw.replace('10.000          100.000','11.000          100.000'),
            self.raw.replace('checking no_clock (0)','checking no_clock (1)'),
            self.raw.replace('checking no_input_delay (18)','checking no_input_delay (17)'),
            self.raw.replace('report_unconstrained','omitted_scope'),self.raw[:100],self.raw+self.raw]
        for bad in mutations:
            with self.subTest(prefix=bad[:20]),self.assertRaises(ValueError):fpga_reports.timing(bad,'Synthesized',False)
    def test_every_timing_failure_and_zero_endpoints_rejected(self):
        good=self.raw.replace('Synthesized','Routed').replace('-5.559    -4283.602                   1515','1.000        0.000                      0')
        self.assertEqual(fpga_reports.timing(good)['setup']['failing_endpoints'],0)
        for before,after in [('0.045        0.000','-0.001       -0.001'),('4.500        0.000','-0.100       -0.100'),
            ('0                 8369','0                    0'),('0                 8369','9000              8369'),('1.000        0.000','NaN          0.000')]:
            with self.subTest(after=after),self.assertRaises(ValueError):fpga_reports.timing(good.replace(before,after))
    def test_resource_caps_latches_and_missing_memory_rejected(self):
        r=fpga_reports.utilization(self.use,'Synthesized');self.assertEqual(r['Slice LUTs']['used'],4625)
        for before,after in [('4625','99999'),('| Block RAM Tile','| Wrong RAM Tile'),('Register as Latch     |    0','Register as Latch     |    1')]:
            with self.subTest(before=before),self.assertRaises(ValueError):fpga_reports.utilization(self.use.replace(before,after),'Synthesized')


if __name__=='__main__':unittest.main(verbosity=2)
