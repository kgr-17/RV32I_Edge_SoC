"""Parse actual Vivado reports conservatively; no fabricated signoff defaults."""
import math
import re


def finite(value):
    result=float(value)
    if not math.isfinite(result):raise ValueError('FPGA_NONFINITE_REPORT_NUMBER')
    return result


def report_header(text,state):
    for expression in (r'Tool Version\s*:\s*Vivado v\.2025\.2 .*Build 6299465',
                       r'Design\s*:\s*basys3_top\s*\|',
                       r'Design State\s*:\s*'+state+r'\s*\|'):
        if not re.search(expression,text):raise ValueError('FPGA_REPORT_HEADER '+expression)
    if not re.search(r'Device\s*:\s*(?:xc7a35tcpg236-1|7a35t-cpg236)\s*\|',text):
        raise ValueError('FPGA_REPORT_DEVICE')


TIMING_CHECKS={'no_clock','constant_clock','pulse_width_clock','unconstrained_internal_endpoints',
    'no_input_delay','no_output_delay','multiple_clock','generated_clocks','loops',
    'partial_input_delay','partial_output_delay','latch_loops'}


def timing(text,state='Routed',require_closure=True):
    report_header(text,state)
    if 'report_unconstrained' not in text or not re.search(r'Ignore I/O Paths\s*:\s*No',text):
        raise ValueError('FPGA_TIMING_PATH_SCOPE')
    matches=re.findall(r'^\d+\. checking ([a-z_]+) \((\d+)\)\s*$',text,re.M)
    checks={}
    for name,count in matches:
        count=int(count)
        if name in checks and checks[name]!=count:raise ValueError('FPGA_CONTRADICTORY_TIMING_CHECK '+name)
        checks[name]=count
    if set(checks)!=TIMING_CHECKS:raise ValueError('FPGA_TIMING_CHECK_INVENTORY')
    for name,count in checks.items():
        if name not in {'no_input_delay','no_output_delay'} and count:
            raise ValueError('FPGA_UNCONSTRAINED_OR_INVALID_INTERNAL_PATH '+name)
    if (checks['no_input_delay'],checks['no_output_delay'])!=(18,17):
        raise ValueError('FPGA_EXTERNAL_PORT_INVENTORY')
    if not re.search(r'^sys_clk\s+\{0\.000 5\.000\}\s+10\.000\s+100\.000\s*$',text,re.M):
        raise ValueError('FPGA_REPORT_CLOCK')
    marker='| Design Timing Summary'
    if text.count(marker)!=1:raise ValueError('FPGA_TIMING_SUMMARY_COUNT')
    section=text.split(marker)[1].split('| Clock Summary')[0]
    rows=[line.split() for line in section.splitlines() if len(line.split())==12 and re.match(r'^\s*-?\d',line)]
    if len(rows)!=1:raise ValueError('FPGA_TIMING_SUMMARY_SHAPE')
    values=list(map(finite,rows[0]));result={}
    for offset,prefix in ((0,'setup'),(4,'hold'),(8,'pulse_width')):
        slack,total,failing,endpoints=values[offset:offset+4]
        if (failing!=int(failing) or endpoints!=int(endpoints) or endpoints<=0 or
            failing<0 or failing>endpoints or total>0):raise ValueError('FPGA_TIMING_ENDPOINT_COUNTS')
        if require_closure and (slack<0 or total!=0 or failing!=0):
            raise ValueError('FPGA_ROUTED_TIMING_FAILED '+prefix+' slack='+str(slack))
        result[prefix]={'worst_slack_ns':slack,'total_negative_slack_ns':total,
            'failing_endpoints':int(failing),'endpoints':int(endpoints)}
    result.update(checks=checks,clock_period_ns=10.0,external_io_delays='UNSPECIFIED:18 async inputs/17 non-synchronous outputs; no off-chip timing closure claim')
    return result


def utilization(text,state):
    report_header(text,state)
    expected={'Slice LUTs':20800,'Slice Registers':41600,'Block RAM Tile':50,'Bonded IOB':106}
    result={}
    for line in text.splitlines():
        if not line.startswith('|'):continue
        fields=[f.strip().rstrip('*') for f in line.split('|')[1:-1]]
        if len(fields)==6 and fields[0] in expected:
            name=fields[0]
            if name in result:raise ValueError('FPGA_DUPLICATE_RESOURCE_ROW')
            used,fixed,prohibited,available,percent=map(finite,fields[1:])
            if available!=expected[name] or not 0<=used<=available or fixed<0 or prohibited<0:
                raise ValueError('FPGA_RESOURCE_CAPACITY '+name)
            if abs(percent-used*100/available)>0.011:raise ValueError('FPGA_RESOURCE_PERCENT')
            result[name]={'used':used,'available':int(available),'percent':percent}
        if fields and fields[0]=='Register as Latch' and int(fields[1])!=0:raise ValueError('FPGA_LATCH_REPORTED')
    if set(result)!=set(expected) or result['Block RAM Tile']['used']!=32 or result['Bonded IOB']['used']!=36:
        raise ValueError('FPGA_RESOURCE_OR_MEMORY_INVENTORY')
    return result
