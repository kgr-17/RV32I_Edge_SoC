# T041 directed RV32I / initial EEI review matrix

November 2, 2026, America/Los_Angeles. **Verification prepared; owner review pending.**
Actual RTL results are pending the formal gates. This matrix covers the declared
40-instruction RV32I 2.1 core and owner-approved v0.2 fault-halt EEI. It records
finite directed tests and their limits; it is not RISC-V certification, exhaustive
proof, privileged-ISA support, or final SoC/hardware signoff.

Architecture identity remains SHA256
`403c527d73aeb22de5dee40c2b0a0dbb7175f9f7197a1a35d48f2ff15c10da03`.
T002 architecture and T018 pipeline owner approvals are recorded. T018's approval
acknowledgment is commit `bf52dd4`; no new architecture change is proposed here.
Production RTL, ports, ISA, map, reset/flush priorities, clocks, XPR/XDC and the
original kit remain unchanged. T041 priority185 precedes T019 priority190;
the previous handoff's T019-first assumption was rejected by the harness and
corrected, without bypassing selection or starting two tasks.

## Instruction matrix

Every row requires an actual executable-pipeline trace matched to the independent
ISS, including successful retirement metadata or the specified precise fault.
All 40 instruction-family bins and nine diagnostic codes are required per seed.
The independent model does not consume the hand-written expected rows. The
hand generator separately checks every expected retirement/fault against that
model before actual RTL execution; this tests the stimulus as well as the DUT.

| Instruction | Directed semantics / corner classes |
|---|---|
| LUI | Upper immediate, negative/high bits, x0 harmless destination |
| AUIPC | PC addition, upper immediate, last-ROM-word result wrap, x0 |
| JAL | Link, redirect/kill, aligned target, misalignment fault, negative target wrap |
| JALR | Link, loaded source, immediate sign, bit0 clear before alignment, 32-bit addition wrap |
| BEQ | Taken/not taken, bad target only on taken branch |
| BNE | Taken/not taken, bad target only on taken, bounded backward loop |
| BLT | Signed negative/positive relation; taken/not-taken misalignment |
| BGE | Signed relation including negative boundary; target qualification |
| BLTU | Unsigned high-bit relation; target qualification |
| BGEU | Unsigned high-bit relation; target qualification |
| LB | Every byte lane, sign extension, high-address final byte, x0 access fault |
| LH | Both aligned lanes, sign extension, high boundary, alignment before map |
| LW | Raw word, data dependence, ROM reads, RAM last word, wrapped address, x0 error |
| LBU | Every byte lane, zero extension, final byte, x0 error |
| LHU | Both aligned lanes, zero extension, alignment priority, x0 error |
| SB | Each lane, shifted payload/mask, dependent store payload |
| SH | Each aligned halfword, masks, misalignment fault before any request |
| SW | Full word, dependency, ROM/unmapped/error faults with no failed byte effects |
| ADDI | Positive/negative immediate limits, result wrap, NOP and x0 HINT |
| SLTI | Signed comparison with -2048/-1/0/1/2047 |
| SLTIU | Sign-extended immediate compared unsigned |
| XORI | Sign-extended immediate and six-value operand set |
| ORI | Sign-extended immediate and six-value operand set |
| ANDI | Sign-extended immediate and six-value operand set |
| SLLI | Amount0/1/31, shifted-out bits; invalid upper encoding rejected |
| SRLI | Logical zero-fill at0/1/31, invalid upper encoding rejected |
| SRAI | Signed right shift at0/1/31, valid funct7 and illegal alternatives |
| ADD | Six-value operand cross, carry/wrap, dependent readback, x0 |
| SUB | Six-value operand cross, borrow/wrap, signed boundaries, x0 |
| SLL | Six-value cross, low-five-bit shift mask including32 |
| SLT | Six-value signed cross including80000000/7fffffff/ffffffff |
| SLTU | Same cross interpreted unsigned |
| XOR | Bitwise cross, high bits and x0 |
| SRL | Unsigned logical shift with masked register amount |
| SRA | Arithmetic shift with masked register amount |
| OR | Bitwise cross and x0 |
| AND | Bitwise cross and x0 |
| FENCE | Older delayed SW, then FENCE, then younger LW/SW; all ignored fields tested |
| ECALL | Exact encoding, code8/tval0, older store completes, younger store killed |
| EBREAK | Exact encoding, code9/tval0, older store completes, younger store killed |

ALU integration values are0,1,ffffffff,80000000,7fffffff,32, with all36 pairs
for all ten register operations; immediate extremes and shifts supplement them.
Existing unit evidence provides larger scalar/decoder/LSU spaces, but cannot be
substituted for the new integration runs. This is finite corner coverage.

## EEI and encoding matrix

The original42 T018 cases and all their collision/nonvacuity checks remain an
exact stimulus prefix. New116 cases bring each seed to158 scenarios and1587
expected successful retirements (8791 input rows include initialization/headers).
Seeds1,7,101,20261102 are replayable. The23 named semantic requirements and
per-seed scenario IDs are exported in a machine-readable evidence/isa matrix.

| Requirement | Test behavior and acceptance |
|---|---|
| FENCE drain / ignored fields | Cases42..45 use0000000f,0ff0000f,8330000f,ffff8f8f. Actual FENCE must wait behind older memory; all four cases need positive wait count, exactly three successful memory effects and no younger effect before FENCE retirement. Ignored rd/rs1/fm/pred/succ do not write/read GPRs or make the instruction illegal. |
| Legal HINTs | LUI/AUIPC and all register/immediate ALU operations with rd=x0 remain harmless; canonical NOP; source GPRs read back unchanged. |
| Illegal M/CSR/system | All eight M funct3 operations, six CSR forms, MRET/WFI/SFENCE-like encodings and nonexact ECALL/EBREAK fields terminate code1. No extension is silently enabled. |
| Illegal fields/extensions | Bad branch/JALR/load/store/shift/register/FENCE funct fields, FENCE.I, compressed/zero/all-ones, atomic and floating encodings terminate code1 with original instruction tval. |
| Alignment before map | LH/LHU/LW and SH/SW misalignments in valid RAM and unmapped space terminate code4/6 before any data request; loads use rd=x0 too. |
| Branch target alignment | All six branches taken to a two-byte-only target fault code2; each corresponding not-taken branch completes normally. JAL/JALR cases also check links are suppressed on misalignment. |
| Access and wrap | Data ROM read allowed, ROM write fault, inaccessible address errors; 32-bit address/target arithmetic, negative JALR immediate, bit0 clearing and last-word boundaries. |
| In-range bus error | Case46: instruction error at ROM0 reports instruction0/code3. Case47: LW x0 at RAM10000 errors code5. Case48: SW to the same valid RAM errors code7 and changes no bytes. Explicit error-word metadata configures the ISS; the SV bus independently drives these errors. |
| Precise termination | Fault PC/instruction/code/tval compared; faulting instruction never retires/writes; older work completes and younger memory is suppressed; sticky halt and old fetch drain preserved. |

Codes1..9 are project diagnostics, not privileged mcause. Misalignment precedes
map/error checking. ECALL/EBREAK provide fatal termination until reset in this
reviewed EEI. Failed stores have no byte effects; loads to x0 still access/fault.
FENCE conservatively orders older memory/I/O responses and younger effects under
one-outstanding buses, even when fm/pred/succ would otherwise request less. The
test memory is ROM/RAM; actual peripheral behavior is separately verified later.

## Execution and evidence policy

`dv/integration/test_isa_complete.py` supplies hand expectations and eight tests.
`tb_isa_complete.sv` instantiates the actual pipeline, retaining complete ordered
retirement, full64KiB RAM, request stability/one-outstanding, duplicate/effect
accounting, bounded progress, sticky fault and killed-fetch drain checks. The
four FENCE cases use deterministic fast IF to force the required collision;
the remaining new cases use variable bus timing with a first32-edge data wait.
All original42 timing modes and requirements stay unchanged.

`retire_checks.py --unit isa_complete` additionally compares the independent
ordered retirement/fault trace, all31 stored GPRs and32 terminal RAM sample
words per case. The sample covers128 bytes at10000; boundary effects are also
carried in complete memory retirement records, and full RAM is checked by SV.
Three actual-trace mutations per seed plus real corrupt-expected/empty XSim runs
must fail. XSim raw exit0 cannot override a fatal diagnostic or missing marker.

`isa_complete_checks.py` rejects missing/stale/newest-failed comparisons, wrong
source/contract/backend hashes, missing families/faults/seeds/state/mutations,
and missing/duplicate/zero-wait/malformed FENCE runtime evidence. It saves the
40+9 family/fault matrix,23 semantic requirements, actual FENCE telemetry and
source/vector/wave/normalized-trace identities. Four matrix-policy and six
inherited acceptance-policy tests supplement the actual comparisons.

The new ISA backend receives a finite120s aggregate child budget for four larger
program sets, within the existing runner cap. Per-XSim30s, version timeouts,
all diagnostics/negatives, three task attempts and process-tree cleanup are
unchanged. No timeout or missing check can pass. Existing backends keep60s.

From the project root, formal finish runs:

```powershell
python -B scripts/verify.py lint
python -B scripts/verify.py test-isa-complete
python -B scripts/verify.py regress
git diff --check
git diff --cached --check
```

The full regression was added to T041's required commands because shared trace
parsing/checker/manifest changes need old-backend validation. Both original
required targets remain; the regression now has15 targets including this suite.
Versions remain Python3.9.13/Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim2025.2
build6299465. Actual exit codes, receipts, seeds, trace/wave paths and results
will be appended after execution. Sources and artifacts remain project-local.

Preparation evidence includes a failed `-m unittest` import of the new checker:
the sibling scripts directory was missing from that invocation's import path.
Added the explicit project-local path; its four policy tests now pass. The
failure remains under evidence/prepare; no RTL, test expectation or gate changed.

## Review limits and next step

The selected ISA and EEI remain the approved local contract; no extra extensions
or privileged software support are implied. Official compiler-based architectural
suites are NOT RUN (no matching compiler/test adapter installed or downloaded).
No RISC-V certification or exhaustive encoding/state proof is claimed. Random
instruction generation T019, assertions/coverage/reset/formal T020..T024,
SoC/MMIO/interrupt T044/T045, FPGA implementation/timing/physical validation and
ASIC remain separate mandatory milestones. In-flight shared-reset testing is
T022; case-boundary resets here cannot close it. Warm reset/CDC policy is unchanged.

After all required commands pass, T041 requires owner review of this finite
matrix and EEI results before T019 may begin. Do not self-approve or change the
architecture to accommodate a failing test. Unrestricted runtime still permits
attended work only; no unattended scheduler or hardware programming is enabled.
