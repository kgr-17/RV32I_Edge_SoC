from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path('scripts').resolve()));sys.path.insert(0,str(Path('dv/integration').resolve()))
import harness,rtl_checks,interrupt_firmware,soc_checks,interrupt_model
c=rtl_checks.Checks('interrupt-wait-preparation',task='T045',scope='Actual enabled pipeline and peripherals with verification-only randomized bus timing shim');code=1
try:
    m=rtl_checks.load_manifest();c.versions(m);rtl=soc_checks.sources(m)
    names=rtl+['dv/integration/tb_interrupt_waits.sv','dv/integration/irq_wait_soc.sv','dv/integration/interrupt_model.py','dv/unit/test_csr.py','sw/interrupt_smoke.S','scripts/interrupt_firmware.py','.tmp/t045_wait_prepare.py']
    c.result['source_sha256']={n:hashlib.sha256(harness.inside(n).read_bytes()).hexdigest() for n in names}
    raw,symbols=interrupt_firmware.build(c,c.base/'compiler');work=c.base/'simulation';work.mkdir()
    harness.atomic_text(work/'irq_boot.mem',harness.inside('fpga/basys3/irq_boot.mem').read_text(encoding='ascii'))
    soc_checks.compile_design(c,work,rtl,['dv/integration/irq_wait_soc.sv','dv/integration/tb_interrupt_waits.sv']);soc_checks.elaborate(c,work,'tb_interrupt_waits','irq')
    for seed in (1,20261107):
        trace=work/('trace-'+str(seed)+'.txt')
        r=soc_checks.simulate(c,work,'irq','boot-'+str(seed),['SEED='+str(seed),'TRACE='+str(trace),'SIG=%x'%symbols['signature']],'/tb_interrupt_waits/clk /tb_interrupt_waits/rst /tb_interrupt_waits/pc /tb_interrupt_waits/tv /tb_interrupt_waits/tc /tb_interrupt_waits/gates',60)
        c.require(rtl_checks.successful(r) and ('IRQ_RUN_COMPLETE seed=%d divisor=8'%seed) in r['stdout'],'Actual random-wait boot completion '+str(seed),r)
        summary=interrupt_model.check_trace(trace.read_text(),raw,symbols,8);harness.atomic(work/('summary-'+str(seed)+'.json'),summary);c.result.setdefault('boot_summaries',[]).append(summary)
        c.require(summary['uart_bytes']==20,'Independent random-wait CSR/ISA/trap/bus/serial check '+str(seed))
    c.result['status']='PASS';code=0
except (RuntimeError,ValueError,KeyError,OSError,harness.Stop) as exc:c.result.update(status='FAIL',error=str(exc))
c.result['artifacts']={p.relative_to(harness.ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in c.base.rglob('*') if p.is_file()};c.save();print(json.dumps({'status':c.result['status'],'receipt':c.path.relative_to(harness.ROOT).as_posix(),'error':c.result.get('error')}));sys.exit(code)
