<!-- entry:5e3cef4ef3144ed5d14d4de511f3dcc5791d07829dbfb26ba23013efdf7e5d37 -->

## November 7 attended T031 recovery

Read the November 6 technical handoff and required engineering contract; ran
daily --supervised (exit 0, .tmp/2026-11-07-daily.txt), inspected Git and resumed
T031 with begin T031 (exit 0). No task verification attempts used. HEAD b94e043.
Earlier fast-divider compiled SoC boot PASS remains preserved, 187 retirements
per boot, PASS CRLF twice, persistent RAM counter 1->2. Production-divider
preparation did run 121330 native cycles but correctly failed its strict gate:
the waveform Tcl referenced inner instead of the wrapper's actual body hierarchy,
causing Simtcl 6-55 WARNING. Preserve the FAIL receipt and sources before repair;
do not reinterpret the process exit 0 as a passed verification.

Continue active T031 only: standalone fabric errors/lanes/stalls/reset cancellation,
production UART boot, independent negative controls, diagnostic compatibility,
recoverable top/project integration. Two-worker independent lint retains every
existing check and 120-second native/600-second aggregate limits; thread-safe
evidence and failure-joining tests are required. Final T031 gates still pending.
Exactly two November 7 reports; prior-day findings retained. Runtime unrestricted,
approval never, attended only. No downloads, installations, global changes,
scheduling, push or FPGA programming. T023 formal skipped/NOT RUN, full FPGA
implementation/timing/bitstream/hardware/ASIC NOT RUN. Next milestone T044 requires
owner architecture review after T031 is completed and committed.


---

<!-- entry:eddd0aae5afd4231fabc606430efc7a6a49171370c5da8af203618fae446efef -->

## T031 implemented; final acceptance gates pending

Actual SoC preparation soc-20261107T205446617903Z PASS60checks/32commands. Fast
seeds1/20261107 each1970cycles/two187-retirement boots; actualcanonicalBasys3top
productiondivider868:121330cycles/two4357-retirement boots,86664Dwaitcycles. Every
phase independently decodes PASS CRLF and matchesISA/bus/entirephysicalRAM;
persistentword1->2. Fabricseeds4006/3970edge rows,268/271distinctRAMwords written
before readback, all64offset/maskcombosperregion, error/fulladdress/ROMwrite/
concurrentROM/heldresponse/UARTbusy/resetcancel.3actualbadinputs, coherentearlyRAM
RTLmutant, corruptactualimage(dataLMAbyte) rejected(cycle39SOC_DMEM_RESPONSE),
9wrong-retirement/truncated/emptytrace controls. No marker-only acceptance.

Saved original10integrationinputs in evidence/prepare/T031-before-integration/
inputs.zip with hashes. diagnostic_top.sv body identical exceptmodulename;
existingboardvectors/negatives/probes preserved. Canonicaltop now reset_sync+
edge_soc withrawRX/switches enteringexisting2FFchainsonce; full23RTL+image+XDC
manifest integrated intoexistingXPR. XPRdiff153addedlinesonly; XDC unchanged.
Sourceintegrationactualreceipt soc-project-integration-20261107T205550441295Z
remainsFAIL because76Board49-26catalog+1emptyBoardPart warning; operationfinished
andindependentexactXMLmanifest PASS. No warnings filtered, noSDKmodified. This
is separatelydisclosed, not warning-free integration. Repro source-onlycommand:
python -B scripts/project_integration.py --apply; checkwithoutmutationomit--apply.

Initialproductionprep soc-production-preparation-20261107T204729669742Z FAIL for
Simtcl6-55(inner vsactualbody hierarchy) despiteprocess0; archived30sources/
64generatedhashes. Lateractualboardtoprunwarningfree. Initialsocdriver
soc-20261107T205408043634Z NOT RUN beforecompilation becausehashmanifestreferenced
dv/unit/test_mmio.py; corrected to existingdv/integration/test_mmio.py. Allreceipts
preserved. Onepureunitassertion used rd_wdata instead of Retirement.rd_data;
corrected test API, no modelbehaviorchange; all7oracletestsPASS.

Standalonefabriclintpreparation soc-fabric-lint-preparation-20261107T205657778564Z
PASS withstrictnative diagnostics. Parallelindependentlintmax2 retainsallprior
designs/negativechecks and120native/600aggregatecaps; RLockserializesreceipt
updates.19policytestsPASS includingboundedconcurrency/failurejoin and12concurrent
command/checkindexbindings.10boardpolicytestsPASS includingexactmanifestnegative
andoldbodyequivalence;6buildpoliciesPASS. NativeTclplan replay PASS(exit0), nofull
targetbuild. Boardcompatibilityreplaystarted, retainactualreceipt. Registry27
retains26earlierregressiontargets; full27regression NOT RUN.

Next finishT031 --evidence evidence/daily/T031.md withallrequiredlint/test-soc/
whitespacegates, atmost3attempts. Auditrawsource/tool/artifact/firmware/trace/wave/
project/snapshotpreservation, appendtodayreports, stage/indexhashcheck/commit then
prepareT044ownerarchitectureproposal. CPU/peripheral/memoryRTL,originalboot/linker/
T026image andapprovedARCH hash403c527d73aeb22de5dee40c2b0a0dbb7175f9f7197a1a35d48f2ff15c10da03
unchanged. Additionalbaselineexistingchanges(test_board_checks.py and
test_fpga_build.py) explicitlyneeded forstrictmanifest/diagnosticequivalence and
config-awareownerpolicytests; baselinearchive retainedunaltered.31complete+1skip/
41untilfinalgate. T023formal NOT RUN/ownerskipped, fulltargetsynth/PPA/CDC/timing/
bitstream/physical/ASIC NOT RUN. Attendedunrestricted/never; noinstall/download/
globalconfig/push/scheduling/programming. ExactlytwoNovember7reports, November6
entries retained. VersionsPython3.9.13/Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim
2025.2 SW6299465; actualGNUtoolpinsunchanged. Every sessionreadlatesthandoffand
requiredcontractfiles,daily--supervised,recoveractivebeforeselectingnext.


---

<!-- entry:c5d51f32ae84076112f2e0fce49d15455ecdb18c00762f20b559f4ec578228c0 -->

## T031 completed: compiled firmware boots on the integrated SoC

All four gates passed on attempt 1, all exit 0: lint, test-soc, git diff --check,
git diff --cached --check. Receipt: evidence/runs/T031/attempt-1-20261107T205937621750Z.json.
Current native receipts: evidence/toolchain_runs/lint-20261107T205938016781Z.json, evidence/toolchain_runs/top-20261107T210340673979Z.json, evidence/toolchain_runs/soc-20261107T210442479446Z.json.
Check/command counts: {"lint": {"checks": 45, "commands": 24}, "top": {"checks": 22, "commands": 13}, "soc": {"checks": 60, "commands": 32}}. Independent policy/oracle tests:
7 SoC, 19 lint, 10 board, 6 build, all PASS. Separate test-top and test-tcl
replays also passed; full 27-target regression NOT RUN. Lint retains all prior
design checks, fixture and latch rejection; two workers completed it in roughly
4 minutes, with native <=120 and aggregate <=600 second limits unchanged.

Final audit evidence/t031-final-audit-2026-11-07.json independently verified
3 receipts, 60 source hashes, 522 artifacts, 1182 unchanged historical files,
125270 positive boot cycles, 9462 retirements, 36 decoded UART bytes and 7976
fabric vectors. Six boots cover two seeds, actual 100MHz board top at divisor868,
cold/warm reset, RAM counter1->2, complete architectural RAM, precise ECALL8
termination after signature600d600d, GPIO/timer/RX and UART busy backpressure.
Actual corrupt-image, early-store RTL mutant and malformed inputs/traces were
rejected. Synthesized fabric and preserved diagnostic are unit evidence only.

Changes: new rtl/soc/{soc_fabric,edge_soc}.sv, sw/soc_smoke.S and separate
soc_boot.mem; native SoC/fabric/board-top DV and independent model; compiler,
integration and validation scripts; canonical top/XPR/source manifest, diagnostic
compatibility and thread-safe bounded lint. Existing CPU/peripheral/memory RTL,
original boot/linker/rom_init.mem, XDC and approved architecture hash are unchanged.
There are 22 canonical RTL files plus one memory image (correction to the earlier
23-RTL shorthand). XPR only adds153 source lines; the original10 integration
inputs remain in a hashed ZIP, and the diagnostic body is byte-equivalent except
module name. Owner approvals, skips, old daily claims/exceptions are unchanged.

Retained limitations: source integration finished but its receipt remains FAIL
for76 installed board-catalog warnings plus1 empty BoardPart warning. Exact XPR
manifest and simulation passed separately; no warning was hidden, no SDK changed.
Initial waveform hierarchy FAIL and missing-source NOT RUN are preserved. Final
whitespace caught my registry CRLF edit (exit2); archived raw ZIP, normalized LF
with identical parsed JSON, then both required whitespace gates passed. Audit-only
unused absolute-path and UTF-8/GBK errors were archived before repair; final audit
passed without changing verified sources. No checks/timeouts were weakened.

Reproduce: python -B scripts/verify.py lint; python -B scripts/verify.py test-soc;
python -B scripts/project_integration.py. Use --apply only for recoverable source
integration into the existing project, no synthesis/programming. Firmware expects
host ASCII A after reset and emits PASS CRLF at approximately115200baud/8N1.
See docs/SOC_BOOT.md. FPGA synthesis/place/route/PPA/fullCDC/timing/bitstream and
physical hardware/ASIC NOT RUN. T023 formal remains owner-skipped/NOT RUN.

Next inspect/stage audited task files, verify all60 index hashes, local commit
from b94e043, then query actual next and begin T044 architecture review. Prepare
a concrete interrupt/CSR/trap proposal without implementing it or altering the
approved v0.2 contract. T044 requires owner review; do not self-approve. Mandatory
progress32 completed plus1 owner skip out of41. Each new session must read latest
handoff/AGENTS/boundary/ARCH/verification/backlog/state/loop and daily --supervised;
recover active task first. Versions Python3.9.13/Git2.48.1.windows.1/tzdata2026.2/
Vivado-XSim2025.2 SW6299465, pinned GNU tools unchanged. Unrestricted/never runtime,
attended only; no download/install/global config/push/scheduler/FPGA programming.
Exactly two November7 reports updated; all prior-date entries retained.


---

<!-- entry:4866761505e224797d0d0e401c8b2de79592a22a52752c232f73eb2639da8b9d -->

## T044 architecture proposal prepared after T031 commit

T031 audited and committed locally as 66bfa46 (65 files, all60 index-source hashes
matched, both whitespace checks exit0). Git was clean; next selected T044 and
begin T044 exit0. Baseline evidence/prepare/T044-baseline-2026-11-07.json records
1245 tracked source hashes. Read current timer/pipeline/decisions before drafting.
Official RISC-V20240411 Zicsr/CSR-list/machine1.13 pages read under existing owner
documentation authorization; exact URLs/sections and engineering inferences in
evidence/t044-sources-2026-11-07.json. No packages/tools/IP downloaded or installed.

New docs/INTERRUPT_SPEC.md is proposal v0.3 only. ADR0013-15 appended toDECISIONS.
Proposes ENABLE_TRAPS legacy-default0 core/SoC, enabled future physical top with
separate firmware; six CSR ops, direct handler, synchronous traps/MRET, specified
CSR masks/resets and new trace fields. CurrenttimerCTRL bit1 is AUTO_RELOAD;
newIRQenable usesbit2, preservesaddresses/count/equality/W1C/reload. Customtimer
drives machine-external cause11, not a claim of standard64-bit mtime or fullM
platform. Drain admittedwork/stablefetch then rechecklevel/masks withpipeline/buses
empty, mepc fromlastretirednext_pc; olderfaultswin, no effectreplay. FullnewCSR/
trap/bus/branch/reset/compiledfirmware/UART/negative/legacyregression acceptance
requirements are explicit. All new featureimplementation/verification NOT RUN.

No RTL/config/XPR/XDC/image/approvedARCH or verification-policy change inT044.
Next run requiredfinishT044 --evidence evidence/daily/T044.md, max3attempts, then
audit baselinepreservation/proposalhashes/ownerstate and commit reviewpackage.
Human review is mandatory perAGENTS/BACKLOG; do not approveonownerbehalf or begin
T045 beforeapproval.32completed+1formalownerskip/41; T023NOT RUN retained. Full
FPGAimplementation/timing/PPA/bitstream/physical/ASIC NOT RUN. BothNovember7reports
appendonly; attendedunrestricted/never, no globalchanges/push/scheduling/programming.
VersionsPython3.9.13/Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim2025.2 SW6299465.


---

<!-- entry:cb9a5d115255449ee5da166514fd8e61285659bbe5a48805af1aa1bcbe6ee2a0 -->

## T044 ready for owner architecture review

T031 is committed as66bfa46. T044 document gates passed on attempt1, exit0:
harness validate and both whitespace checks. Receipt evidence/runs/T044/attempt-1-20261107T211422904365Z.json.
This establishes workflow/document readiness only; no trap/CSR/interrupt RTL or
functional result. State is awaiting_review, active=None; next returns planning_only
with no executable task. Human review remains an explicit hold beforeT045.

Review package: docs/INTERRUPT_SPEC.md v0.3, appendedADR0013-15 inDECISIONS.md,
evidence/t044-sources-2026-11-07.json and evidence/t044-review-manifest-2026-11-07.json.
Proposal SHA256: 86dca0ef075734c57029be58c8a4f75a63540ef18384017489db3e2a4626c17d.
Audit preserved1242 baselinefiles, everyRTL/config/XPR/XDC/image/check/approvedARCH
unchanged; threeallowed historicaldocuments retain their exactpriorprefixes.
Allownerreviews/startapprovals/skips/legacyclaims/exceptions unchanged. No owner
command called. ExactlytwoNovember7reports, bothT031 andT044 participation saved.

Owner must review feature-selected compatibility, CSR/mask/reset/trace definitions,
timer CTRLbit2 preservingbit1reload, customtimer via machine-external cause11,
precise drain/IRQ-level recheck, synchronous traps/MRET and T045 acceptance scope.
No standard64-bit timer or fullprivilegedplatform claim. Currentnewfeatures all
NOT IMPLEMENTED/NOT RUN. T023formal remainsownerskipped/NOT RUN; fullFPGA/physical/
ASIC claims remainabsent and executionauthorizations separate. No waiver inferred.

Before stopping review/stage package, verifyindexproposalhashes/whitespace, commit
locally, then present concrete committed package forreview. Nextsession: readthis
latesthandoff andallcontractfiles,daily--supervised,Gitstatus. IfT044stillawaits
review, do notbeginT045. Owner can explicitlyapprove thepackage andrun
python -B scripts/harness.py approve T044 --confirm-owner-review; AGENTS reserves
ownercommands, so do notcallonownerbehalf without explicittask-specific direction.
Afterreviewisrecorded, inspectcleanstate/querynext/beginT045 andimplementexact
approvedproposalwithreproducibleevidence; donotclaimexistingT031tests coverthe
newmode.32mandatorycompleted+1ownerskip/41, T044awaitsreview. Toolsunchanged:
Python3.9.13/Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim2025.2 SW6299465.
Attendeddanger-full-access/never; noinstall/download/globalconfig/push/scheduling/
FPGAprogramming. Allrecords/project remainrecoverable inlocalGit andsavedarchives.


---

<!-- entry:59ddb6081930cb7c8bab3a3076c2856bdf9855b3ace2ae437b7e7f2bf79568b9 -->

## Committed review package and shutdown/resume point

T031 implementation/evidence commit66bfa46d08d69dbebaa4ec8d6d60de1cce82fa34.
T044 proposal/evidence package commit80bd35e (all13 inspected files staged, four
review-source index hashes matched, whitespace exit0). Git clean after commit;
status validates32completed,1owner-skipped,1awaiting_review,0blocked/failed/active.
T044 exact proposal SHA256 remains86dca0ef075734c57029be58c8a4f75a63540ef18384017489db3e2a4626c17d.

Present this committed package to the owner; approval is still pending. Stop
implementation at the AGENTS.md architecture-review / BACKLOG T044 gate. No owner
approval command has run. Owner may review docs/INTERRUPT_SPEC.md and explicitly
authorize the task-specific approval command or run it personally. On receipt,
record only that authorized acknowledgment, commit the resulting review state,
then query next and begin T045 from clean Git. Otherwise keep the review hold;
no daily quota or technical-failure claim is involved. The report-only commit
records these known package IDs; it changes no proposal or verified source.


---

<!-- entry:d4f42fabc077ce1044ded72b6a1a9346130e2c48a23e9a3cfd69e9077ab85ff8 -->

## T044 owner approval recorded; proceed to T045

Owner explicitly replied "Approve v0.3 and authorize that command" to review of
package80bd35e. Verified unchanged proposal SHA25686dca0ef075734c57029be58c8a4f75a63540ef18384017489db3e2a4626c17d,
then executed exactly python -B scripts/harness.py approve T044 --confirm-owner-review,
exit0. T044 completed and its owner review is recorded. Supplemental exact owner
authorization: evidence/owner_reviews/T044-2026-11-07-authorization.json.
daily --supervised exit0 saved .tmp/2026-11-07-t045-daily.txt; Git was clean at
b741095. Read latest handoff/AGENTS/boundary/ARCH/verification/backlog/state/loop
and the approved interrupt proposal. Runtime remains unrestricted/never, attended
only; no scheduling/install/global changes/programming. This grants T045 scope,
not T043 or T032 execution permission. Commit acknowledgment, then query/begin
T045 from clean Git and establish baseline before RTL edits.33mandatory completed
plus1owner-skip/41; new feature functionality still NOT RUN; formal T023 retained.


---

<!-- entry:fcc47e48988bc609351da3af9e86c66a68bbe8451bf32afa26c7d8ebf7091251 -->

## T045 active: first enabled CSR/trap/timer SoC boot passed

Owner approval recorded f9d05e0; began T045 from clean Git. Baseline tracked
source hashes in evidence/prepare/T045-baseline-2026-11-07.json. No finish attempts
used. Added csr_file/trap_control, enabled decoder IDs41..47 (packed57-bit legacy
decode unchanged), feature-constant pipeline CSR serialization/precise traps/
drain-recheck and separate observations. Core/SoC default legacy0; timer bit2 IRQ
enabled only with feature, preserves bit1 reload. Existing images/constraints/
approved v0.2 and v0.3 documents untouched. Canonical FPGA top remains legacy
until full enabled native validation and recoverable integration.

Four independent CSR model tests PASS. Actual csr-preparation-20261108T011427355331Z
PASS10checks/8commands:6424 pre/post vectors per seed1/20261107,12848total, CSR
masks/read-only/zero-index-vs-value/trap/MRET/reset/admission cancellation. First
legacy SoC prep soc-boot-preparation-20261108T011559866077Z strictly FAIL on new
unconnected output warning; archived28 sources and generated hashes before binding
all added outputs explicitly. Same legacy expectations then passed in
soc-boot-preparation-20261108T011638471997Z, preserving old compiled program.

Actual pinned GNU RV32I_Zicsr build interrupt-firmware-20261108T011955511938Z PASS;
new sw/interrupt_smoke.S + existing boot/linker produce separate irq_boot.mem.
Enabled interrupt-boot-preparation-20261108T012206694452Z PASS:7318cycles,
two747-retirement boots, all nine synchronous mcause classes plus externalIRQ11,
all six CSR operations, nested synchronous frame save/restore, MRET, timer W1C,
20 independently decoded IRQ PASS CRLF bytes,354RAM effects, persistentword1->2.
Independent CSR/ISA/bus/peripheral/RAM/serial checker passed; no marker-only test.

Continue soleactiveT045: unit defect controls/lint, random bus waits and direct
IRQ mask/cancel/reset/interactions across seeds, production868/actualtop boot,
mode-aware source/image integration, runtime contract and complete test-interrupts
driver. Full27existing regression targets plus new IRQ target must all run;
old19-target run was478seconds, added EDA targets justify bounded2-worker
independent regression under unchanged600 aggregate/120native limits. Preserve
every command, order/evidence/failure and old expectations; test orchestration.
Do not reserve finish until preparation is concrete; max3attempts. Record both
reports before final gates, audit current/source/artifact/baseline and commit.
FormalT023 stays ownerskipped/NOT RUN; fullFPGA synth/route/timing/PPA/fullCDC/
bitstream/physical/ASIC NOT RUN, approvals remain separate. No install/download/
globalconfig/push/scheduling/programming; attendedunrestricted/never. LAdateNov7,
UTCNov8. VersionsPython3.9.13/Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim2025.2
SW6299465. New sessionreads latesthandoff plusrequiredcontractfiles/daily and
recoversT045; do notselectanother task orclaimfeaturecomplete from preparations.


---

<!-- entry:713b14720933582767f78422538240208edd29b7706659f7fa6830847c905ae5 -->

## T045 implementation prepared for final gates

Latest full interrupt script preparation interrupts-20261108T014955485553Z PASS
119checks/59commands. Four CSR unit tests and seven independent IRQ model tests
PASS. Both seeds1/20261107 cover CSR/timer vectors, fast boots, random request/
response waits, level cancellation during drain, six reset-aborted states then
two complete boots, and an actual fault/IRQ collision. The latter uses a recorded
verification-only illegal instruction patch after the polling load; source IRQ is
admitted while the fault is in EX, and native IRQ_FAULT_WON>=2 confirms synchronous
fault precedence. All effects/retirements/traps/CSR state/wholeRAM/UART are checked
independently; disabled observation metadata must be zero and RAM cannot execute
CSR/MRET encodings. Native wrong-resume core plus four unit RTL mutants rejected;
six bad-vector, five bad-trace and actual corrupt-image controls rejected.

Actual production Basys3 top at868 passed179302cycles/two2895-retirement boots,
20IRQ PASS CRLF bytes, persistentword1->2. Standalone enabled CPU/CSR/admission
lint PASS6checks/3commands (newCPU49.641s); explicit aligned30-bit internal CSR
trap-PC adapter removed true unused-input warnings without changing32-bit core
PC or masking diagnostics. Enabled timer lint is registered for final full lint.

Project now includes newCSR/admission sources andirq_boot.mem, retainsoldimage,
adds20XPRlines/no deletions. Backup evidence/prepare/T045-before-integration/.
Source-only integration soc-project-integration-20261108T013838027098Z remainsFAIL
forinstalled board-catalog warnings, exactmanifestPASS separately. Newcore/SoC
defaults0 preservelegacy; canonicaltopdefaults1/newimage. LegacyboardTBexplicitly
selects0/soc_boot.mem. New runtimecontract has52ports and binds exactT044specSHA;
approvedv0.2/v0.3 submissions, XDC, boot/linker, priorimages andkit unchanged.

Failures retained before repairs: legacyunconnectedports(28inputs), waitwrapper
syntax(30), unusedCSRalignmentbits(18), cancellationwindow(30), prioritywindow
(62), plusdriverPythonparseZIP. Sourcewindowrepairs changeDVstimulus only; required
cancellation/fault-priority checks remain. Passing108check checkpoint archived
beforepriorityextension. PowerShell redirection gaveNativeCommandError despite
43unittestOK; rawoutputZIPretained. Exactargv policies thenPASS exits[0,0,0]
in evidence/prepare/T045-policy-checks.json (dispatcher2,budget5,harness43).

scripts/verify.py now runs only independent regression targets withmax2 workers,
all28targetsretained, declaredresultindices preserved, each completion flushed
atomically so laterfailure cannot erase earliercommandoutput. Larger appended
suites startfirst; ordinarychecks staysequential. Concurrency/exception/NOTRUN/
ordering tests passed; original600aggregate/120native caps unchanged. Full28
regression NOT RUN yet. Registry/newdriverready; requiredfinishT045 next with
lint,test-interrupts,regress,andwhitespace, max3attempts(current0). Do not reuse
preparationPASS asfinaltaskgate. Onfailure preserveallinputs/receipts beforefix;
never weakenchecks. Nativeartifact roots underbuild/T045; allactual logs/hashes.

Next runcheck_interrupt_contract, inspectdiff, finish, auditallcurrentreceipts/
source/artifacts/baseline/ownerstate, appendbothreports andcommitinspectedfiles.
Thenquerynext expectedT043ownerexecutiongate; prepareconcreteplan andrequestowner
authorization, never self-authorize or programhardware.33mandatorycomplete+1skip/
41 beforeT045finishes. T023formal NOT RUN/ownerskipped. FullSoCimplementation,
timing/PPA/fullCDC/bitstream/physical/ASIC NOT RUN. Runtimeunrestricted/never,
attendedonly. No download/install/globalconfig/push/scheduler/FPGAprogramming.
ExactlytwoNovember7reports, priorentriesretained. VersionsunchangedPython3.9.13/
Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim2025.2 SW6299465, pinnedGNUtools.
