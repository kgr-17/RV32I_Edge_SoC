# Interrupt implementation evidence (T045 active)

## T045 active: first enabled CSR/trap/timer SoC boot passed

Owner approval recorded f9d05e0; began T045 from clean Git. Baseline tracked
source hashes in evidence/prepare/T045-baseline-2026-11-07.json. No finish attempts
used. Added csr_file/trap_control, enabled decoder IDs41..47 (packed57-bit legacy
decode unchanged), feature-constant pipeline CSR serialization/precise traps/
drain-recheck and separate observations. Core/SoC default legacy0; timer bit2 IRQ
enabled only with feature, preserves bit1 reload. Existing images/constraints/
approved v0.2 and v0.3 documents untouched. Canonical FPGA top remains legacy
until full enabled native validation and recoverable integration.

Four independent CSR model tests PASS. Actual csr-preparation-20261108T011427355331Z
PASS10checks/8commands:6424 pre/post vectors per seed1/20261107,12848total, CSR
masks/read-only/zero-index-vs-value/trap/MRET/reset/admission cancellation. First
legacy SoC prep soc-boot-preparation-20261108T011559866077Z strictly FAIL on new
unconnected output warning; archived28 sources and generated hashes before binding
all added outputs explicitly. Same legacy expectations then passed in
soc-boot-preparation-20261108T011638471997Z, preserving old compiled program.

Actual pinned GNU RV32I_Zicsr build interrupt-firmware-20261108T011955511938Z PASS;
new sw/interrupt_smoke.S + existing boot/linker produce separate irq_boot.mem.
Enabled interrupt-boot-preparation-20261108T012206694452Z PASS:7318cycles,
two747-retirement boots, all nine synchronous mcause classes plus externalIRQ11,
all six CSR operations, nested synchronous frame save/restore, MRET, timer W1C,
20 independently decoded IRQ PASS CRLF bytes,354RAM effects, persistentword1->2.
Independent CSR/ISA/bus/peripheral/RAM/serial checker passed; no marker-only test.

Continue soleactiveT045: unit defect controls/lint, random bus waits and direct
IRQ mask/cancel/reset/interactions across seeds, production868/actualtop boot,
mode-aware source/image integration, runtime contract and complete test-interrupts
driver. Full27existing regression targets plus new IRQ target must all run;
old19-target run was478seconds, added EDA targets justify bounded2-worker
independent regression under unchanged600 aggregate/120native limits. Preserve
every command, order/evidence/failure and old expectations; test orchestration.
Do not reserve finish until preparation is concrete; max3attempts. Record both
reports before final gates, audit current/source/artifact/baseline and commit.
FormalT023 stays ownerskipped/NOT RUN; fullFPGA synth/route/timing/PPA/fullCDC/
bitstream/physical/ASIC NOT RUN, approvals remain separate. No install/download/
globalconfig/push/scheduling/programming; attendedunrestricted/never. LAdateNov7,
UTCNov8. VersionsPython3.9.13/Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim2025.2
SW6299465. New sessionreads latesthandoff plusrequiredcontractfiles/daily and
recoversT045; do notselectanother task orclaimfeaturecomplete from preparations.


---

## T045 implementation prepared for final gates

Latest full interrupt script preparation interrupts-20261108T014955485553Z PASS
119checks/59commands. Four CSR unit tests and seven independent IRQ model tests
PASS. Both seeds1/20261107 cover CSR/timer vectors, fast boots, random request/
response waits, level cancellation during drain, six reset-aborted states then
two complete boots, and an actual fault/IRQ collision. The latter uses a recorded
verification-only illegal instruction patch after the polling load; source IRQ is
admitted while the fault is in EX, and native IRQ_FAULT_WON>=2 confirms synchronous
fault precedence. All effects/retirements/traps/CSR state/wholeRAM/UART are checked
independently; disabled observation metadata must be zero and RAM cannot execute
CSR/MRET encodings. Native wrong-resume core plus four unit RTL mutants rejected;
six bad-vector, five bad-trace and actual corrupt-image controls rejected.

Actual production Basys3 top at868 passed179302cycles/two2895-retirement boots,
20IRQ PASS CRLF bytes, persistentword1->2. Standalone enabled CPU/CSR/admission
lint PASS6checks/3commands (newCPU49.641s); explicit aligned30-bit internal CSR
trap-PC adapter removed true unused-input warnings without changing32-bit core
PC or masking diagnostics. Enabled timer lint is registered for final full lint.

Project now includes newCSR/admission sources andirq_boot.mem, retainsoldimage,
adds20XPRlines/no deletions. Backup evidence/prepare/T045-before-integration/.
Source-only integration soc-project-integration-20261108T013838027098Z remainsFAIL
forinstalled board-catalog warnings, exactmanifestPASS separately. Newcore/SoC
defaults0 preservelegacy; canonicaltopdefaults1/newimage. LegacyboardTBexplicitly
selects0/soc_boot.mem. New runtimecontract has52ports and binds exactT044specSHA;
approvedv0.2/v0.3 submissions, XDC, boot/linker, priorimages andkit unchanged.

Failures retained before repairs: legacyunconnectedports(28inputs), waitwrapper
syntax(30), unusedCSRalignmentbits(18), cancellationwindow(30), prioritywindow
(62), plusdriverPythonparseZIP. Sourcewindowrepairs changeDVstimulus only; required
cancellation/fault-priority checks remain. Passing108check checkpoint archived
beforepriorityextension. PowerShell redirection gaveNativeCommandError despite
43unittestOK; rawoutputZIPretained. Exactargv policies thenPASS exits[0,0,0]
in evidence/prepare/T045-policy-checks.json (dispatcher2,budget5,harness43).

scripts/verify.py now runs only independent regression targets withmax2 workers,
all28targetsretained, declaredresultindices preserved, each completion flushed
atomically so laterfailure cannot erase earliercommandoutput. Larger appended
suites startfirst; ordinarychecks staysequential. Concurrency/exception/NOTRUN/
ordering tests passed; original600aggregate/120native caps unchanged. Full28
regression NOT RUN yet. Registry/newdriverready; requiredfinishT045 next with
lint,test-interrupts,regress,andwhitespace, max3attempts(current0). Do not reuse
preparationPASS asfinaltaskgate. Onfailure preserveallinputs/receipts beforefix;
never weakenchecks. Nativeartifact roots underbuild/T045; allactual logs/hashes.

Next runcheck_interrupt_contract, inspectdiff, finish, auditallcurrentreceipts/
source/artifacts/baseline/ownerstate, appendbothreports andcommitinspectedfiles.
Thenquerynext expectedT043ownerexecutiongate; prepareconcreteplan andrequestowner
authorization, never self-authorize or programhardware.33mandatorycomplete+1skip/
41 beforeT045finishes. T023formal NOT RUN/ownerskipped. FullSoCimplementation,
timing/PPA/fullCDC/bitstream/physical/ASIC NOT RUN. Runtimeunrestricted/never,
attendedonly. No download/install/globalconfig/push/scheduler/FPGAprogramming.
ExactlytwoNovember7reports, priorentriesretained. VersionsunchangedPython3.9.13/
Git2.48.1.windows.1/tzdata2026.2/Vivado-XSim2025.2 SW6299465, pinnedGNUtools.
