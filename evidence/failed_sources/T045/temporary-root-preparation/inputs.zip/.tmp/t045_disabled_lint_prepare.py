from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path('scripts').resolve()))
import harness,rtl_checks
c=rtl_checks.Checks('disabled-lint-repair',task='T045',scope='Strict legacy-port synthesis specializations plus full enabled pipeline; no diagnostic filtering');code=1
try:
    m=rtl_checks.load_manifest();designs=[d for d in m['lint_designs'] if d['top'] in ('pipeline_cpu_lint_top','timer','pipeline_irq_lint_top')]
    names=list(dict.fromkeys([n for d in designs for n in d['sources']]+['config/rtl_checks.json','scripts/rtl_checks.py','scripts/vivado_lint.tcl','scripts/tool_runner.py','.tmp/t045_disabled_lint_prepare.py']))
    c.result['source_sha256']={n:hashlib.sha256(harness.inside(n).read_bytes()).hexdigest() for n in names}
    c.lint_manifest(dict(m,lint_designs=designs))
    work=c.base/'bad-definition';work.mkdir();source=work/'sources.txt';definition=work/'defines.txt'
    harness.atomic_text(source,str(harness.inside('dv/toolchain/register_fixture.sv'))+'\n');harness.atomic_text(definition,'RV32_CORE_LEGACY_PORTS\n')
    r=c.vendor('vivado',['-mode','batch','-nolog','-nojournal','-notrace','-source',str(harness.inside('scripts/vivado_lint.tcl')),'-tclargs',str(source),'register_fixture','xc7a35tcpg236-1',m['vivado_version'],str(definition)],work/'tool',15)
    c.require(r['status']=='FAIL' and 'UNEXPECTED_LINT_DEFINES' in r['stdout']+r['stderr'] and 'TOOLCHAIN_LINT_PASS' not in r['stdout'],'Native Tcl rejects definition outside exact legacy unit',r)
    # The specialization cannot silently disable a live interrupt configuration.
    d=next(d for d in designs if d['top']=='pipeline_cpu_lint_top');work=c.base/'wrong-enabled';work.mkdir()
    probe=work/'pipeline_cpu_lint_top.sv';text=harness.inside('dv/lint/pipeline_cpu_lint_top.sv').read_text(encoding='utf-8')
    c.require(text.count('pipeline_core dut (')==1,'Unique feature guard mutation')
    harness.atomic_text(probe,text.replace('pipeline_core dut (',"pipeline_core #(.ENABLE_TRAPS(1'b1)) dut ("))
    source=work/'sources.txt';definition=work/'defines.txt'
    harness.atomic_text(source,'\n'.join(str(probe) if n=='dv/lint/pipeline_cpu_lint_top.sv' else str(harness.inside(n)) for n in d['sources'])+'\n');harness.atomic_text(definition,'RV32_CORE_LEGACY_PORTS\n')
    r=c.vendor('vivado',['-mode','batch','-nolog','-nojournal','-notrace','-source',str(harness.inside('scripts/vivado_lint.tcl')),'-tclargs',str(source),'pipeline_cpu_lint_top','xc7a35tcpg236-1',m['vivado_version'],str(definition)],work/'tool',60)
    c.require(r['status']=='FAIL' and 'LEGACY_PORTS_REQUIRE_TRAPS_OFF' in r['stdout']+r['stderr'] and 'TOOLCHAIN_LINT_PASS' not in r['stdout'],'Native source guard rejects specialization with traps enabled',r)
    c.result['status']='PASS';code=0
except (RuntimeError,ValueError,KeyError,OSError,harness.Stop) as exc:c.result.update(status='FAIL',error=str(exc))
c.result['artifacts']={p.relative_to(harness.ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in c.base.rglob('*') if p.is_file()};c.save();print(json.dumps({'status':c.result['status'],'receipt':c.path.relative_to(harness.ROOT).as_posix(),'error':c.result.get('error')}));sys.exit(code)
