from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path('scripts').resolve()))
import harness,rtl_checks
c=rtl_checks.Checks('interrupt-lint-preparation',task='T045',scope='CSR/admission and enabled pipeline unit synthesis lint, not full SoC FPGA build');code=1
try:
    m=rtl_checks.load_manifest();designs=[d for d in m['lint_designs'] if d['top'] in ('csr_lint_top','trap_control','pipeline_irq_lint_top')]
    names=list(dict.fromkeys([n for d in designs for n in d['sources']]+['config/rtl_checks.json','scripts/rtl_checks.py','scripts/vivado_lint.tcl','.tmp/t045_lint_prepare.py']))
    c.result['source_sha256']={n:hashlib.sha256(harness.inside(n).read_bytes()).hexdigest() for n in names}
    c.lint_manifest(dict(m,lint_designs=designs));c.result['status']='PASS';code=0
except (RuntimeError,ValueError,KeyError,OSError,harness.Stop) as exc:c.result.update(status='FAIL',error=str(exc))
c.result['artifacts']={p.relative_to(harness.ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in c.base.rglob('*') if p.is_file()};c.save();print(json.dumps({'status':c.result['status'],'receipt':c.path.relative_to(harness.ROOT).as_posix(),'error':c.result.get('error')}));sys.exit(code)
