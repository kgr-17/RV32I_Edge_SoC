#!/usr/bin/env python3
"""Independent acceptance tests for incomplete, mislabeled and excluded bins."""
from pathlib import Path
import sys
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from dv.coverage.coverage_report import GROUPS, FEATURES, excluded, parse_bins, summarize
from dv.random.test_random_programs import generate, REQUIRED_BINS, NEGATIVE_FULL_PROGRAM
NEGATIVE_DIAGNOSTIC='COVERAGE_MISMATCH fault'


class CoverageTests(unittest.TestCase):
    def setUp(self):
        self.bins={(g,f):int(excluded(GROUPS[g],FEATURES[f]) is None) for g in range(8) for f in range(8)}
        self.text='\n'.join('COVERAGE_BIN seed=7 group=%d feature=%d hits=%d'%(g,f,h) for (g,f),h in self.bins.items())

    def test_exact_matrix_and_justified_exclusions(self):
        result=summarize(parse_bins(self.text,7),{'op:ADD':1},['op:ADD'])
        self.assertEqual(result['counts'],dict(matrix=64,reachable=49,hit=49,uncovered=0,excluded=15))
        self.assertTrue(all(row['exclusion'] for row in result['excluded_crosses']))

    def test_reachable_uncovered_is_reported_not_erased(self):
        self.bins[1,1]=0
        result=summarize(self.bins,{'op:ADD':1},['op:ADD'])
        self.assertEqual([(r['group'],r['feature']) for r in result['uncovered_crosses']],[('load','ex_forward')])
        self.assertEqual(result['counts']['reachable'],49)

    def test_missing_required_opcode_feature_or_redirect_cross_rejected(self):
        for changed,isa in ((dict(self.bins),{}),({k:(0 if k[1]==1 else h) for k,h in self.bins.items()},{'op:ADD':1}),
                            ({**self.bins,(3,7):0},{'op:ADD':1}),({**self.bins,(7,0):0},{'op:ADD':1})):
            with self.assertRaises(ValueError):summarize(changed,isa,['op:ADD'])

    def test_hits_cannot_be_hidden_under_exclusion(self):
        with self.assertRaises(ValueError):summarize({**self.bins,(5,1):1},{'op:ADD':1},['op:ADD'])

    def test_missing_duplicate_wrong_seed_invalid_and_empty_telemetry_rejected(self):
        for text,seed in ((self.text,1),(self.text+'\n'+self.text,7),('\n'.join(self.text.splitlines()[1:]),7),
                          (self.text.replace('hits=1','hits=x'),7),('',7)):
            with self.assertRaises(ValueError):parse_bins(text,seed)

    def test_instrumented_bench_preserves_assertion_and_existing_guards(self):
        root=Path(__file__).resolve().parents[2]
        old=(root/'dv/assertions/tb_assertions.sv').read_text().replace('ASSERTIONS_','COVERAGE_')
        new=(root/'dv/coverage/tb_coverage.sv').read_text()
        for line in old.splitlines():
            if 'fail(' in line or '$fatal(' in line:self.assertIn(line.strip(),new)
        self.assertIn('core_properties monitor',new)


if __name__=='__main__':unittest.main(verbosity=2)
